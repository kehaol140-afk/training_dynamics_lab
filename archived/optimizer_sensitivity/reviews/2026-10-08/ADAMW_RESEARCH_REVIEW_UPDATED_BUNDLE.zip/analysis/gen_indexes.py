#!/usr/bin/env python3
"""Generate the five index CSVs for the updated AdamW audit bundle."""
import csv, os

AUD = "/home/b205/projects/training_dynamics_lab/audits/ADAMW_RESEARCH_REVIEW_UPDATED_20261008_051201UTC"

def w(name, header, rows):
    with open(os.path.join(AUD, name), "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(header)
        wr.writerows(rows)
    print(f"wrote {name}: {len(rows)} rows")

# ---------------- MODEL_INDEX ----------------
w("MODEL_INDEX.csv",
  ["model_id","project","name","mathematical_content","key_assumptions","current_status","source_refs"],
  [
   ["M-TAN","optimizer_sensitivity","AdamW tangent linearization (B/C/SO arms)",
    "dz_{h+1}=J_h(alpha)dz_h+s_h over augmented state z=(theta,m,v); B arm alpha=0 (optimizer-only), C arm alpha=1 (clip_jvp o HVP curvature feedback), SO impulse at h=1 then source-off; metrics G_B,G_C,R_curv=G_C/G_B,G_SO,lambda_SO=ln(G_SO)/H",
    "local linearization valid at small tangent amplitude; HVP clipping keeps feedback bounded; bank states from real checkpoints cover phase x seed x scale",
    "ACTIVE backbone (F0-F4 all units)","docs F0-F4 series; outputs/f{0,1,2,2_5,3,3_5}_*; outputs/f4*_"],
   ["M-VFL","optimizer_sensitivity","v-floor causal closure (F1)",
    "v-floor perturbs theta' channel with effect proportional to v_hat^(-3/2)",
    "v-floor is the dominant low-variance path into parameter update",
    "FROZEN CONFIRMED","outputs/f1_mechanism/summary.json (b3adb732...)"],
   ["M-HG","optimizer_sensitivity","practical hypergradient estimator (F2)",
    "finite-difference/hypergradient estimates over eta grid with engineering-feasible variance reduction",
    "estimator variance manageable at practical budget",
    "FROZEN FAILED (PRACTICAL_HYPERGRADIENT_FAILURE)","outputs/f2_hypergradient/summary.json (7069c2ae...)"],
   ["M-TR","optimizer_sensitivity","trust-region surface (F2.5)",
    "S_eta,h_eta over eta scans; collapse indicator under correlated vs identity spectra",
    "spectral correlation is the discriminating factor",
    "FROZEN CONFIRMED (collapse correlated-only); re-confirmed H_best==1 in F4B/F4C","outputs/f2_5_trust_region/summary.json (083b312a...)"],
   ["M-SPEC","optimizer_sensitivity","spectral instability model (F3/F3.5)",
    "top tangent eigenvalue rho>1.05 instability criterion; unstable-mode coupling; metric dependence",
    "power iteration captures dominant tangent mode",
    "FROZEN CONFIRMED with metric-dependence caveat","outputs/f3_curvature_mechanism/summary_final.json; outputs/f3_5_mode_coupling/summary.json"],
   ["M-M0","optimizer_sensitivity","F4A.5 canonical macro model M0 (progress-only)",
    "predicting late-phase tangent indicators from progress features only; pooled-OOF + LOSO CV; Huber robustness",
    "progress carries the predictable macro structure; seed variance irreducible (41.79%)",
    "CANONICAL (LOSO MAE 0.4249; fold median 0.4041)","outputs/f4a5_modeling/{dataset,model_comparison,loso_predictions}.csv"],
   ["M-M1M5","optimizer_sensitivity","F4A.5 candidate models M1 scale-only / M2 +scale / M3 +phase / M4 full / M5 interaction",
    "nested extensions of M0 with scale/phase/interaction features",
    "extra structure may improve OOF",
    "REJECTED (worse LOSO than M0; prescreen DISABLED_BY_PREREG balacc 0.539)","outputs/f4a5_modeling/model_comparison.csv"],
   ["M-SAU","optimizer_sensitivity","stability-aware unrolling policy (F4B)",
    "online lambda_hat(H) vs grid {1,2,8,16,32,64}, stop/shrink-eta actions; delta=0.05 main + 0.02 sensitivity",
    "lambda_hat observable online; action grid covers operating range",
    "DEGENERATED to FIXED H=1 (lambda_hat(2)~0.35-0.38 > B_lambda=0.30); NO_METHOD_GAIN","outputs/f4b_sau/summary.json; summary_delta0.02.json"],
   ["M-OBS","optimizer_sensitivity","observability gap diagnostic (F4B postmortem)",
    "offline AUROC for instability separation vs online-achievable AUROC; delta grids",
    "offline diagnostic uses privileged information unavailable online",
    "SUPPORTED: offline 0.8367 / online 0.685 (d.05); 0.7904/0.6728 (d.02)","outputs/f4b_postmortem/{online_observability,offline_diagnostic}.csv"],
   ["M-HSUF","optimizer_sensitivity","horizon-sufficiency utility model (F4B postmortem)",
    "H_suff per cell from utility_by_horizon (nregret); sufficiency distribution",
    "regret saturates beyond sufficient horizon",
    "UTILITY_ALREADY_SHORT_HORIZON: median H_suff=1; >=90% cells H_suff<=2","outputs/f4b_postmortem/{utility_by_horizon,horizon_sufficiency}.csv"],
   ["M-P4","continuation_adaptation","P4 sealed evaluation + gate model",
    "56 cells x 8 arms = 448 runs; stage2 sealed 280-row table; stage3 Holm + 4-gate continue/stop",
    "CRN across arms; sealed table immutable after SEAL_LOCK",
    "STOP frozen: C1 +1.587064 nats (0/8 seeds, Holm p=1.0); C2 +0.019356","outputs/p4_full/stage2/sealed_evaluation_table.csv; stage3/analysis_report.json"],
   ["M-LEG","legacy_fluctuation_response","FR/GTTR historical chains (A0/CALFIX/F0-IC/D1/E3C...)",
    "predecessor fluctuation-response mechanisms; archived after 2026-09-29 cleanup",
    "historical reference only",
    "FROZEN (HEAD 6ac4942; no research writes after 2026-09-30)","docs/FR_PROJECT_STATUS.md (36229054...)"],
  ])

# ---------------- EXPERIMENT_INDEX ----------------
w("EXPERIMENT_INDEX.csv",
  ["experiment_id","project","question_tested","design","scale","key_artifacts","verdict","recompute_check"],
  [
   ["F0","optimizer_sensitivity","does tangent ill-conditioning worsen with scale?","power iteration on tangent Jacobian across bank scales","multi-scale bank","outputs/f0_existing_bank_audit/power_iteration.csv","TANGENT_ILL_CONDITIONING_AT_SCALE","hash==old manifest; frozen"],
   ["F1","optimizer_sensitivity","is v-floor the causal channel into theta'?","mechanism closure with v-floor perturbation","bank states","outputs/f1_mechanism/summary.json","V_FLOOR_CAUSAL (prop v_hat^-3/2)","hash==old manifest; frozen"],
   ["F2","optimizer_sensitivity","can practical hypergradients guide eta?","estimator variance/bias under engineering budgets","pilot grid","outputs/f2_hypergradient/summary.json","PRACTICAL_HYPERGRADIENT_FAILURE","hash==old manifest; frozen"],
   ["F2.5","optimizer_sensitivity","does trust region collapse universally?","S_eta,h_eta surfaces correlated vs identity spectra","eta scans","outputs/f2_5_trust_region/summary.json","TRUST_REGION_COLLAPSE_CORRELATED_ONLY","hash==old manifest; frozen"],
   ["F3","optimizer_sensitivity","spectral instability mechanism?","tangent spectrum across settings; rho>1.05","multi-config","outputs/f3_curvature_mechanism/summary_final.json","SPECTRAL_INSTABILITY + METRIC_DEPENDENT","hash==old manifest; frozen"],
   ["F3.5","optimizer_sensitivity","unstable mode coupling?","mode-coupling analysis","multi-config","outputs/f3_5_mode_coupling/summary.json","report final","hash==old manifest; frozen"],
   ["F4-A","optimizer_sensitivity","phase x scale x seed structure of instability/healing?","74 bank states (5M/26M/100M x EARLY/MID/LATE x seeds) x 6 steps; interval-censored healing","444-row map","outputs/f4a_phase_map/{phase_map_long,phase_map_summary,healing_intervals}.csv","PHASE_STRUCTURE_ONLY_NO_SCALE_TREND; strict healing 13/14","recomputed G/R per cell from raw; PASS"],
   ["F4A.1","optimizer_sensitivity","is 5M MID-only coverage biasing scale trend?","16 new 5M states with reconstructed legacy recipe + canary seed 2030","16 states + canary","outputs/f4a1_matched_coverage/{matched_phase_map,matched_summary,canary_envelope}.json/csv","NONMONOTONIC_SCALE_STRUCTURE; EARLY lambda_SO monotone in N","canary 5 prereg gates verified from raw (stream_id 4090); PASS"],
   ["F4A.5","optimizer_sensitivity","is macro evolution predictable?","90-state dataset; 6 nested models; pooled-OOF + LOSO; prereg prescreen gate","90 states","outputs/f4a5_modeling/{dataset,model_comparison,loso_predictions,variance_decomposition}.csv","M0 canonical (LOSO MAE 0.4249); MODEL_PRESCREEN DISABLED_BY_PREREG","all six models' OOF recomputed == CSV; PASS"],
   ["F4B","optimizer_sensitivity","can SAU beat fixed unrolling online?","delta=0.05 main grid + 0.02 sensitivity; per-cell regret; oracle analysis","42 cells x 6H","outputs/f4b_sau/{summary,summary_delta0.02}.json; per_method_regret.csv","NO_METHOD_GAIN (SAU==FIXED1 bitwise; oracle median H=1)","SAU/FIXED1 bitwise equality; PASS"],
   ["F4B-POST","optimizer_sensitivity","why no gain - observability or utility?","offline vs online AUROC; horizon sufficiency; utility by horizon","504 utility rows","outputs/f4b_postmortem/{summary,online_observability,offline_diagnostic,horizon_sufficiency}.csv/json","OBSERVABILITY_GAP_SUPPORTED + UTILITY_ALREADY_SHORT_HORIZON","504-row check + AUROC recompute; PASS"],
   ["F4C","optimizer_sensitivity","does intervention benefit scale with N?","H2-H1 regret contrasts; seed-clustered bootstrap; STAGE D confirmatory gated","42 cells","outputs/f4c_mining/{mining_summary,f25_micro_surface}.json","WEAK_SCALE_DEPENDENCE (sign flips with delta); STAGE D DISABLED","bootstrap CIs reproduced exactly; PASS"],
   ["F4-CONS","optimizer_sensitivity","are F4 headline numbers consistent?","14 headline items re-verified against artifacts","14 items","outputs/f4_consistency/headline_numbers.csv","CONSISTENCY_RESTORED (12 VERIFIED/3 STALE_REPORT/1 OVERWRITTEN)","read + spot recompute; PASS"],
   ["P4","continuation_adaptation","do continuation-adaptation arms beat A_best retrain?","56 cells x 8 arms = 448 runs; stage1 selection, stage2 SEAL (280 rows), stage3 Holm+4 gates","448 runs","outputs/p4_full/stage2/{sealed_evaluation_table.csv,SEAL_LOCK.json}; stage3/analysis_report.json","STOP (C1 +1.587064, C2 +0.019356, 0/8 seeds; Holm p=1.0)","independent recompute from sealed table; PASS"],
   ["LEG-TRACE","legacy_fluctuation_response","historical provenance for bank/recipe","GTTR/A0/CALFIX/D1/E3C chains; 2026-09-29 cleanup archived","legacy","docs/FR_PROJECT_STATUS.md","reference only","git HEAD 6ac4942; hash==old manifest; frozen"],
  ])

# ---------------- KEY_RESULTS ----------------
w("KEY_RESULTS.csv",
  ["result_id","project","metric","value","interval_or_detail","source","status"],
  [
   ["KR-01","continuation_adaptation","C1 - A_best mean (nats)","+1.587064","CI [1.2283,1.9644] (stage3 [1.2352,1.9550]); Holm p=1.0; 0/8 seeds","outputs/p4_full/stage3/analysis_report.json","CONFIRMED"],
   ["KR-02","continuation_adaptation","C2 - A_best mean (nats)","+0.019356","CI [0.0140,0.0247]; 0/8 seeds","outputs/p4_full/stage3/analysis_report.json","CONFIRMED"],
   ["KR-03","continuation_adaptation","B - A_best / D - A_best / B - D (nats)","-0.013881 / +0.060853 / -0.074735","descriptive only; B-D CI [-0.0810,-0.0687]","outputs/p4_full/stage3/analysis_report.json","CONFIRMED descriptive"],
   ["KR-04","optimizer_sensitivity","F4-A strict sustained healing","13/14","seed 2032 NOT_HEALED_IN_COVERAGE (erratum corrected from 14/14)","outputs/f4a_phase_map/healing_intervals.csv","CONFIRMED"],
   ["KR-05","optimizer_sensitivity","F4-A LATE-phase curvature neutrality","24/24 R_curv~1","universal late-phase curvature-neutral","outputs/f4a_phase_map/phase_map_long.csv","CONFIRMED"],
   ["KR-06","optimizer_sensitivity","F4A.1 EARLY lambda_SO monotonicity in N","+1.0","monotone score; R_curv non-monotone","outputs/f4a1_matched_coverage/matched_summary.csv","CONFIRMED"],
   ["KR-07","optimizer_sensitivity","F4A.1 canary stream_id","4090","= 4074 + 16 new states; distribution-equivalence PASS; loss h=1 7.443730","outputs/f4a1_matched_coverage/canary_envelope.json","CONFIRMED"],
   ["KR-08","optimizer_sensitivity","F4A.5 M0 LOSO MAE","0.4249","fold median 0.4041 canonical (erratum text 0.4219 = typo); seed variance 41.79%","outputs/f4a5_modeling/model_comparison.csv","CONFIRMED"],
   ["KR-09","optimizer_sensitivity","F4A.5 prescreen balanced accuracy","0.539","< prereg threshold -> MODEL_PRESCREEN DISABLED_BY_PREREG","outputs/f4a5_modeling/summary.json","CONFIRMED"],
   ["KR-10","optimizer_sensitivity","F4B SAU vs FIXED H=1","bitwise equal","cause: lambda_hat(2)~0.35-0.38 > B_lambda=0.30 grid cap","outputs/f4b_sau/summary.json","CONFIRMED"],
   ["KR-11","optimizer_sensitivity","F4B oracle best-H median","1","dominant-subset BEST_FIXED median regret 0.3165 vs SAU 0","outputs/f4b_sau/summary.json","CONFIRMED"],
   ["KR-12","optimizer_sensitivity","F4B delta=0.02 best fixed","H=32 mean 0.1317","SAU 0.1810","outputs/f4b_sau/summary_delta0.02.json","CONFIRMED"],
   ["KR-13","optimizer_sensitivity","F4B H2-H1 regret difference (d.05 / d.02)","+0.0512 / -0.0746","CIs [+0.000,+0.113] / [-0.158,+0.000]; sign flip","outputs/f4c_mining/mining_summary.json","CONFIRMED"],
   ["KR-14","optimizer_sensitivity","F4B-post offline vs online AUROC (d.05)","0.8367 vs 0.685","d.02 H_sep=1: 0.7904 / balacc 0.6728","outputs/f4b_postmortem/{offline_diagnostic,online_observability}.csv","CONFIRMED"],
   ["KR-15","optimizer_sensitivity","F4B-post horizon sufficiency","median H_suff=1","92.9% (d.05) / 90.5% (d.02) cells H_suff<=2","outputs/f4b_postmortem/horizon_sufficiency.csv","CONFIRMED"],
   ["KR-16","optimizer_sensitivity","F4C verdict","WEAK_SCALE_DEPENDENCE","STAGE D confirmatory DISABLED_BY_PREREG","outputs/f4c_mining/mining_summary.json","CONFIRMED"],
   ["KR-17","optimizer_sensitivity","F4 consistency audit","12 VERIFIED / 3 STALE_REPORT / 1 OVERWRITTEN","all dispositioned; CONSISTENCY_RESTORED","outputs/f4_consistency/headline_numbers.csv","CONFIRMED"],
   ["KR-18","optimizer_sensitivity","Decision memo direction ranking","A mechanism > B observability > C finite-intervention-timescale","D method unsupported; E stop unnecessary; external validation option 2 preferred","docs/F4_POSTMORTEM_DECISION_MEMO.md","NEW"],
   ["KR-19","optimizer_sensitivity","F0-F3.5 + legacy + P4 frozen identity","11/11 + 4/4 hashes match old manifest","byte-identical since 2026-09-30 audit","analysis/verify_out.txt","CONFIRMED"],
  ])

# ---------------- CLAIM_LEDGER ----------------
w("CLAIM_LEDGER.csv",
  ["claim_id","claim","classification","evidence","old_audit_disposition","current_status"],
  [
   ["C-01","Tangent ill-conditioning worsens with scale (F0)","finding","outputs/f0_existing_bank_audit/power_iteration.csv","held","UNCHANGED"],
   ["C-02","v-floor causally closes into theta' with v_hat^-3/2 scaling (F1)","finding","outputs/f1_mechanism/summary.json","held","UNCHANGED"],
   ["C-03","Practical hypergradients fail under engineering budgets (F2)","finding","outputs/f2_hypergradient/summary.json","held","UNCHANGED"],
   ["C-04","Trust-region collapse is correlated-spectrum-only (F2.5)","finding","outputs/f2_5_trust_region/summary.json","held","UNCHANGED; re-corroborated by F4B/F4C H_best==1"],
   ["C-05","Spectral instability exists (rho>1.05) but is metric-dependent (F3/F3.5)","finding","outputs/f3_curvature_mechanism/summary_final.json","held with caveat","UNCHANGED"],
   ["C-06","Instability has phase structure with self-healing","finding","outputs/f4a_phase_map/*","not established (17/74 units at window end)","NEW CONFIRMED; strict healing 13/14; LATE 24/24 curvature-neutral"],
   ["C-07","A monotone scale law of instability exists","hypothesis","outputs/f4a_phase_map/summary.json; f4a1 matched_summary","expected from F4-A","WITHDRAWN -> NONMONOTONIC_SCALE_STRUCTURE; only EARLY lambda_SO monotone in N"],
   ["C-08","Macro evolution is predictable from progress alone (M0)","finding","outputs/f4a5_modeling/model_comparison.csv","not tested","NEW CONFIRMED (LOSO MAE 0.4249)"],
   ["C-09","Micro per-cell trauma is predictable","hypothesis","outputs/f4a5_modeling/summary.json","not tested","WITHDRAWN (prescreen balacc 0.539; DISABLED_BY_PREREG)"],
   ["C-10","SAU yields method gain over fixed unrolling","method claim","outputs/f4b_sau/summary.json","proposed direction in old report","WITHDRAWN (NO_METHOD_GAIN; SAU==FIXED1 bitwise)"],
   ["C-11","Online observability gap is structural","finding","outputs/f4b_postmortem/*","not tested","NEW CONFIRMED (0.8367 offline vs 0.685 online)"],
   ["C-12","Utility already concentrates at H<=2","finding","outputs/f4b_postmortem/horizon_sufficiency.csv","not tested","NEW CONFIRMED"],
   ["C-13","Intervention benefit weakly scale-dependent, delta-sensitive","finding","outputs/f4c_mining/mining_summary.json","not tested","NEW CONFIRMED"],
   ["C-14","P4 continuation adaptation: C1/C2 inferior to A_best; STOP","finding","outputs/p4_full/stage3/analysis_report.json","held (frozen)","UNCHANGED (hash-identical, recompute-identical)"],
   ["C-15","External validation on second recipe/dataset 50M-150M is next gate","plan","docs/F4_POSTMORTEM_DECISION_MEMO.md; EXTERNAL_VALIDATION_PLAN.md","general outlook","REVISED concrete option 2 preferred; NOT EXECUTED this round"],
   ["C-16","F4 doc-level numeric presentation defects","defect register","analysis/RECOMPUTE_NOTES.md sec.5","n/a","NEW: 4 items, none affecting verdicts"],
  ])

# ---------------- COVERAGE ----------------
w("COVERAGE.csv",
  ["unit","project","docs_read","artifacts_verified","recompute_level","status_at_20261008"],
  [
   ["F0","optimizer_sensitivity","F0_EXISTING_BANK_SENSITIVITY_AUDIT.md","power_iteration.csv + hash","hash + frozen","COMPLETE"],
   ["F1","optimizer_sensitivity","F1_MECHANISM_CLOSURE.md","summary.json + hash","hash + frozen","COMPLETE"],
   ["F2","optimizer_sensitivity","F2_HYPERGRADIENT_PILOT*.md","summary.json + hash","hash + frozen","COMPLETE"],
   ["F2.5","optimizer_sensitivity","F2_5_TRUST_REGION_{PREREG,REPORT}.md; F2_5_RESUME_AUDIT.md","summary.json + hash","hash + frozen","COMPLETE"],
   ["F3/F3.5","optimizer_sensitivity","F3_CURVATURE_MECHANISM_{PREREG,REPORT,FINAL_REPORT}.md; F3_5_*; F3_OPENCODE_TAKEOVER_AUDIT.md","summary_final.json; f3_5 summary.json + hash","hash + frozen","COMPLETE"],
   ["F4-A","optimizer_sensitivity","F4A_* (inventory/facts/prereg/report/erratum/missing-coverage)","phase_map_long/summary/healing_intervals/indicator_correlations/exploratory_models/summary.json","full CPU recompute from raw per-cell; median_high convention check","COMPLETE"],
   ["F4A.1","optimizer_sensitivity","F4A1_RECONSTRUCTION_AUDIT; MATCHED_COVERAGE_{PREREG,REPORT}","matched_phase_map/summary; canary_envelope + canary raw metrics","canary 5 prereg gates from raw; stream_id arithmetic; trajectory spot check","COMPLETE"],
   ["F4A.5","optimizer_sensitivity","FORMAL_MODELING_{PREREG,REPORT}; METRIC_ERRATUM; THESIS_MODELING_FRAMEWORK","dataset/model_comparison/loso_predictions/variance_decomposition/predictor_ablation/huber_robustness/summary","all six models pooled-OOF recomputed == CSV; fold median 0.4041 confirmed","COMPLETE"],
   ["F4B","optimizer_sensitivity","STABILITY_AWARE_UNROLLING_{PREREG,REPORT}; ARTIFACT_ERRATUM","summary.json; summary_delta0.02; per_method_regret/selected_horizons/evaluation_cells","SAU==FIXED1 bitwise; oracle median H; dominant-subset regrets","COMPLETE"],
   ["F4B-POST","optimizer_sensitivity","POSTMORTEM_OBSERVABILITY_{PREREG,REPORT}","summary; utility_by_horizon(504); horizon_sufficiency; online/offline csv; observability_frontier","504-row structural check; AUROC/balacc recompute; H_suff distribution","COMPLETE"],
   ["F4C","optimizer_sensitivity","INTERVENTION_SCALE_MINING_{PREREG,REPORT}","mining_summary; f25_micro_surface","seed-clustered bootstrap CIs reproduced exactly","COMPLETE"],
   ["F4-CONS","optimizer_sensitivity","F4_CONSISTENCY_PROVENANCE_AUDIT","headline_numbers.csv; f4a5_metric_recompute.json","read + spot recompute","COMPLETE"],
   ["SYNTH","optimizer_sensitivity","RESEARCH_SYNTHESIS_F0_F4B; THESIS_MODELING_FRAMEWORK_FINAL; F4_POSTMORTEM_DECISION_MEMO; EXTERNAL_VALIDATION_PLAN","n/a (documents)","n/a","COMPLETE"],
   ["P4","continuation_adaptation","P4_PROTOCOL.md","sealed table (280 rows); SEAL_LOCK; stage3 report; sealed_evaluation.json","independent recompute of all primary/secondary contrasts from sealed table","COMPLETE FROZEN"],
   ["LEGACY","legacy_fluctuation_response","FR_PROJECT_STATUS.md","git HEAD 6ac4942; FR_PROJECT_STATUS hash","hash == old manifest; mtime scan (only .pyc newer)","FROZEN reference only"],
   ["OLD-BUNDLE","audits/reference","ADAMW_RESEARCH_REVIEW.md (full); PROGRESS.md; BUNDLE_MANIFEST.json","sha256 map used as identity baseline","n/a (historical comparison only)","COMPLETE"],
  ])

print("ALL CSV INDEXES DONE")
