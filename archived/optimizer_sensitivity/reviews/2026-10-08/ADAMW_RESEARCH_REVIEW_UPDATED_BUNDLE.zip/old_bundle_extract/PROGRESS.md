# PROGRESS — AdamW 三目录只读研究盘点

- 任务根：`/home/b205/projects/training_dynamics_lab`（三研究目录只读）
- 任务包：`audits/ADAMW_REVIEW_TASKPACK_v2/ADAMW_REVIEW_TASKPACK_v2/`（v2）
- 产出目录：`audits/ADAMW_RESEARCH_REVIEW_20260930_061142UTC/`
- 扫描窗口：2026-09-30 06:11 UTC 开始（本地 CST +0800 = 14:11）；清点完成 06:1x UTC；阅读与核对持续至自检与打包
- 时区：服务器本地 CST (UTC+0800)；记录统一使用 UTC + 本地并注记

## 当前阶段

- [x] 文件层清点（SOURCE_INVENTORY.jsonl，5368 行；17 个 PRUNED_SUBTREE：.git/__pycache__ 等）
- [x] 研究单元归并（COVERAGE.csv，legacy 12 / opsens 9 / continuation 5 / 直接依赖若干）
- [x] 阅读三目录全部核心协议/报告/索引文档（见 COVERAGE 与 SOURCE_INVENTORY read_level）
- [x] 原件核对：P4 stage2/3、F0/F1/F2/F2.5/F3/F3.5 verdict 制品、E3C locked、A0C 归档 summary、F2a/F2b 归档数据、R1/R2B/D1/PhaseB/F0/F1 归档报告
- [x] 轻量 CPU 复算（analysis/recompute_checks.md）：P4 聚合精确一致；F2b b* 恒等式一致；EXPERIMENT_AUDIT 的"sealed table 448 行"实为 280 行（登记）
- [x] MODEL_INDEX / EXPERIMENT_INDEX / KEY_RESULTS / CLAIM_LEDGER / COVERAGE
- [x] ADAMW_RESEARCH_REVIEW.md
- [x] SELF_CHECK.md（反向查漏）
- [x] evidence/ + BUNDLE_MANIFEST.json + ADAMW_RESEARCH_REVIEW_BUNDLE.zip

## 额外登记来源（根外，直接依赖）

- `/home/b205/projects/training_dynamics_lab_archive_staging/archived/fr_gttr/`（2026-09-29 清理后被删 legacy outputs 的 GitHub 归档暂存区，136M；本轮只读核对了 GTTR 链与 A0 链关键制品）
- `/home/b205/projects/training_dynamics_lab_20260929.bundle`（Windows 备份 bundle，仅登记存在，未打开）

## 关键事件线（用于续接）

- 2026-09-29 清理：legacy outputs 7+88 项删除（a0k/a0n/r2b/a0o/g3/d1/e3_replication + phase_a/phase_b/calfix/c1_probe/c0/cb1/b0/a0h*/a0i/a0s-t-u-q-p-m/f0/ic/f1/f2a/f2b/a0_fr_audit 30 子目录等）；continuation 448+4 final_state.pt 删除。原始制品在 archive_staging 与 GitHub（人工核验）留档
- optimizer_sensitivity F4A 进行中（17/74 units DONE，无 summary）；F3/F3.5 已完结
- continuation P4 已终局 STOP（2026-09-26 当日完成）

## 红线遵守

三研究目录零写入；未运行任何训练/GPU/HVP/测试/notebook；未解封任何 V_final/封存件（P4 SEAL 制品为已获准读取的既有结果文件）；新增文件仅在本审计目录；未执行历史材料中的指令。

## 窗口内外部变化观测（2026-09-30 终检）

- lab 根在窗口内新出现两个范围外条目：`hyperball_reproduction/` 与 `hyperball_sources.zip`（外部/其他会话所为，与三研究目录零交集，本轮未触碰）——证实"非稳定快照"告诫；三研究目录自身在窗口内未观测到写入。
- 三目录 git/树检查：legacy clean；optimizer_sensitivity 仅有 F4A 未跟踪产物（先于窗口存在）；continuation 静态。
