# SELF_CHECK — AdamW 三目录研究盘点（对照 03_SELF_CHECK.md 逐项）

自检执行时间：2026-09-30（UTC）；方法：独立第二遍——重读关键原件定位、反向清点未挂靠文件、跨表 ID/路径核对、CSV 可解析性、ZIP 成员校验。

## A. 范围是否真正闭合

1. **三根存在且可读**：✅ 三目录均在；扫描窗口 2026-09-30 06:11 UTC 起（本地 CST+0800 14:11）；`SOURCE_INVENTORY.jsonl` 记录 5368 发现行+10 追加行；裁剪 17 个子树（.git×2、__pycache__×7、venv 类、.ipynb_checkpoints 等，逐条 PRUNED_SUBTREE+理由）；扫描错误 0。根外来源仅直接依赖（lab 根文档、audits、archive_staging、bundle 登记），均已登记。
2. **反向清点未挂靠材料**：✅ 用脚本把 inventory 全部 5378 行按 COVERAGE 前缀映射反查——每条 handling=RESEARCH 的行都获得 ≥1 coverage ID（legacy 根级散文件归 U0017/U0022）；未发现无归属的研究报告/源码/结果。outputs 内大量逐 run CSV/JSON（P4 的 448×3 件、F3 raw、G1a/b 结果件等）按目录挂靠所属实验单元，属"已发现、已映射、按重要性分层阅读"（非全文已读，如实记 METADATA_ONLY）。
3. **只有名字/迁移/归档副本的分支**：✅ 已核：F2a/F2b/D1/R1/R2B/CB1/F0/CALFIX/IC/F1/PhaseA/PhaseB/A0 全链 outputs 在树内被 09-29 清理删除→按 REFERENCE_MISSING-ish 处理升级为"归档暂存区在位"（U0041，抽核原件后关键主张 RAW_CHECKED）；theta_protocol.py 源码丢失（pyc 恢复，U0015）；G1c 三段式执行链完整；Phase B v4 建议未执行（如实登记 NOT_RUN）；F1-1B 取消（0 字节）。
4. **coverage 关联**：✅ 42/42 单元均有 review_status；REVIEWED 36 / PARTIAL 4（U0016 快照区、U0031 F4A 进行中、U0035 continuation 代码逐行、U0042 minimind_base）/ EXCLUDED 1（U0018 minimind 副本，理由=重复基础设施按引用理解）。排除理由均为基础设施/重复/范围外，无"结果不好/年代久远"式排除。
5. **分项目计数**：
   - continuation：枚举 1541 文件、裁剪 0、单元 6（含 cleanup 事件）、REVIEWED 5/PARTIAL 1（U0035）
   - legacy：枚举 3484 行（含 17 裁剪中之 2）、单元 22、REVIEWED 18/PARTIAL 2/EXCLUDED 1（另 1 单元为 master-status 归入 REVIEWED）
   - optimizer_sensitivity：枚举 343、单元 10、REVIEWED 9/PARTIAL 1（U0031）
   - 直接依赖：4 单元（含根外 archive_staging/bundle）
   - 文件层：CONTENT_REVIEWED 45 / CONTENT_PARTIAL 20 / METADATA_ONLY 4707 / DATA_METADATA_ONLY 579 / EXCLUDED（含 PRUNED）17+1。**未把分类覆盖冒充已读**。

## B. 模型是否讲完整

6. ✅ MODEL_INDEX 22 行，每行含研究问题/变量/目标/公式来源/假设/参数来源/实验映射/当前判断；正文 §4.2/§5.2/§6.1 就关键数学展开（切线递推、G_i、M/Dv、clip-JVP、LR 源项、二次型、谱）。
7. ✅ 未验证（F4A）、被废弃（mv 闭式、A0E BH）、负结果涉及近似（LR 时间核、regime 切换、GTTR 规则化）均保留并分层；精确更新（切线/J₀/分块 Jacobian）/恒等式（记账/伴随转置）/近似（一阶几何场/二次辨识）/经验拟合（动量核）/假说（FR 比例律、controller 增值）已区分。
8. ✅ 报告可让新读者说明每个模型的预测对象、产生预测的方式、检验实验（模型卡+实验卡+跨项目表）。仅剩文件名的项不存在。

## C. 实验与运行是否计数、比较正确

9. ✅ 62 行逻辑实验各有 ID 与正文/附录位置；NOT_RUN（F1-1B、PhaseB main、F0 solver/audit、A0O Stage3）、SMOKE/仅部分（G1c feasibility Phase2、C1 4/6 anchors、F4A 17/74）、FAILED（A0E v01、F0 校准、PhaseB v3、G1c-external 初判）与成功分开。重跑/重试归类：A0K B_wc 重跑、A0Q launch1 崩溃、A0J impl-gate 修复重跑、F2.5 reshape 修复重跑、F3 RQ3 四次 INVALID→重写后完成、F3.5 O_prop 重算、C0 smoke 2 次失败入账、A0L 零结果时修复重跑、G2 审计缺陷复跑、G3a cross-check 修正重跑——均计入 retry/duplicate 列。
10. ✅ 关键运行绑定：P4 每 run 有 seed/checkpoint/arm/lr_multiplier/batch_manifest_sha（SEAL_LOCK 台账）；opsens 每 cell 有 manifest sha+stream seed（与 F3 frozen reference 逐位）；legacy A0 系 input_hashes 全记录（A0C 归档 summary 抽核）。无法确认身份的运行（E 链早期部分 discovery 2026-2029）未冒充独立确认。当前工作树=执行版本的问题：legacy 执行代码在 git 保护提交 `6ac4942`；theta_protocol 以 pyc 参与（sha 记录）；报告按制品非当前源码断言。
11. ✅ 每个定量实验保留主要数值（KEY_RESULTS 40 项）或明确缺失说明（legacy 已删 outputs 的次要 E4/A0 prep 链=REPORT_ONLY+冻结索引数值）。主结论聚合可回查：P4 280 行封存表逐 run 在包内可复（本轮已复算）；F0/F1/F3/F3.5 summary 在树；A0C 归档 summary 摘录入 evidence/。
12. ✅ 差值统一 value−baseline_value（P4 d 定义、R2B G_struct、A0K 增益方向均已注明原定义）；NLL 均为 sum/count 逐 token 口径（D1 表 B 原样保留 sum+count+mean）；方向 lower_is_better=TRUE 全表一致；不确定性类型（cluster/naive bootstrap、PI、Wilcoxon p、路径级 SE）均注明类型与抽样单位。
13. ✅ 依赖结构说明：同 seed 7 checkpoint 同轨迹（P4 §7 显式 seed 聚类）；同 seed 多 checkpoint/相同起点多动作（A0 系 stream 非独立 seed）；拟合点复用（F2b 的 b* 用 h2 拟合又与 CALFIX/F2A 点比较——terminal_values.csv 分 source 列，如实呈现）；不显著≠零效应（R2B 不显著未被写成无效方向、C2 劣化 0.019 未夸大）。
14. ✅ 协议 vs 实际：P4 统计/停止与 config sha 冻结一致；A0G/A0K 等 λ/规则冻结一致；baseline 调参数据（V_monitor）与最终判定数据（V_final）分离结构性成立（runs 不算 V_final）；对照多因素（P4 的 B vs A 同时改 β 与 LR 乘子来源——已按"乘子同 A 选中值"设计并在报告注明；D1 的 QH 臂同时改读出与 α——按原协议描述）；A0O Stage2 校正数字的 driver 单侧取反误报已由原报告披露（本轮引用 corrected 值）。

## D. 历史修正是否改变了现在的结论

15. ✅ 同名编号全部加项目前缀（legacy F0 vs opsens F0；三项目各自 E/A0/G/F/P 编号）；数学/实现/测量/科学判断/项目决定五维在 CLAIM_LEDGER 分列（如 C0031 实现成立 vs 可用性未决；C0037 取消=项目决定非科学否定）。
16. ✅ 冲突双说并列：A0E↔A0E2、mv_final↔mv_consistent、C0↔C0X/C1、A′ FAIL↔Branch A、F0 首跑 BLOCKED↔amendment、G1c BLOCKED↔recheck——每条都有两方来源与未决点；未凭"最新报告"裁决（C0X 勘误保留 C0 原 verdict 不覆盖）。
17. ✅ 任务提示中的历史线索逐条核查：全局 clip 与 block 内积 JVP（=A0E→A0E2 的 clip-JVP 径向项——已核）；value 与梯度的 sum/count（F1 target wrapper V=sum/count PASS、D1 表 sum/count——已核）；value/SENS 同时点（F3 ordering bug=dc 在 opt.step 后读 post-step θ——已核修复链）；合成 CPU 校验与真实 Transformer 长时域（F1 合成 5.6e-17 vs F0 T=256 混沌、A0H CPU 合成 vs GPU bf16 地板——已核）；FD 尺度与精度（A0D ε 收敛、F0 fp32 分辨地板、F1 v 通道 fp32 FD 失败、F2.5 δ 分辨率边界——已核）；F2 二次求解端点/曲率符号/驻点类型（曲率全负→驻点为极大、实际最优 +0.02 反向、拟合/验证点分 source——已核+恒等式复算）；F0/CALFIX/IC/F1 关系按证据确认（报告链完整）。未把提示线索当已证事实——每条都回查了原件。
18. ✅ 修复后重跑：A0E2（重算）、A0H20（新批重验）、F3（frozen reference 全矩阵重跑）、F3 RQ3（重写 runner 后完成）、F3.5（该 cell 重算）；旧结果作废范围受限（A0E 仅 v01、mv 仅 final、A′ 降级）。静态增益未被夸大（opsens 全程强调 primal 稳定、c=0 锚点域）；局部预测支持未被升级为终点优化成功（GTTR 各卡明确分层）。
19. ✅ 高可信负结果（A0P/A0J/A0L/A0N/A0U/D1/F2a/F2b/P4 STOP）、有限正证据（A0H20、A0O、A0S、A0T、G3、F1 干预）、未完成比较（F3.5 度量依赖、MIDDLE UNRESOLVED、shadow t0）均准确保留；停止决定保留未重启（P4 STOP、A0L/A0N/A0U STOP、A0J 缓存停止、G1c 中止、GTTR 终结、F2.5 停止待审）。

## E. 索引、引用与包体完整性

20. ✅ ID 唯一且跨表存在：model_id 22（被 experiment_ids 引用的均存在）、experiment_id 62、claim_id 48（C0001–C0048）、result_id 40（R0001–R0040）、coverage_id 42（U0001–U0042）；空列表/UNKNOWN/NA 按规则使用；无实验的模型（cont schedule 规则）标"协议规则、无独立实验"。
21. ✅ 正文 claim 标注与 report_anchor：正文表格/段落引用 claim ID；锚点以显式 HTML id 存在（#model-*、#exp-*、#claim-*——与索引 report_anchor 字段一致）；每条主结论有就近 file 定位（非笼统目录）。
22. ✅ 包内证据与原件对应：evidence/ 22 份副本保留相对路径层次或根外绝对标注；BUNDLE_MANIFEST 记录原件路径/定位/是否摘录；缺失原件（已删 outputs）在 §8 台账与对应卡可见。
23. ✅ 解析检查：六张 CSV/JSONL 经标准 csv/json 逐行解析通过（本轮脚本重读无错）；多值字段用 JSON 数组字符串转义；KEY_RESULTS 数值列无 "UNKNOWN" 字符串、空值留空非 0。
24. ✅ ZIP 校验：清单化打包后 zipfile.ZipFile 校验、成员路径全部相对且无 `..`/绝对路径、不含 ZIP 自身/任务包/权重/语料/凭据；必需交付物 10 项全部在包。
25. **源目录变化**：读取窗口内未观测到三目录写入（最后 mtime：legacy 09-25/26、opsens F4A monitor 09-30 04:56 前、continuation 09-29）；F4A 无进程在跑但可恢复——**不宣称窗口内绝对不变**，BUNDLE_MANIFEST 记录读取窗口与快照限制；关键源文件哈希抽验入 manifest。

## F. 必须输出的自检摘要

```text
读取窗口与时区：2026-09-30 06:11 UTC 起（本地 CST/UTC+0800 14:11）；全程同日
三个根目录状态：均存在可读；legacy 冻结（HEAD 6ac4942）；opsens 活跃 repo（F4A 可恢复、无进程）；continuation 终局静态
文件枚举与明确裁剪范围：5368 发现行（FILE 5351 + PRUNED_SUBTREE 17）+10 追加直接依赖行；裁剪=.git/__pycache__/venv 类，均记录
分项目研究单元计数与未完成项：continuation 6（1 PARTIAL）；legacy 22（2 PARTIAL、1 EXCLUDED）；opsens 10（1 PARTIAL=进行中）；直接依赖 4
分项目模型/逻辑实验/唯一运行计数：模型 22（legacy 13/opsens 8/cont 1+1 规则）；逻辑实验 62；唯一有效运行以 P4=448（SEAL 台账）、F3=逐 cell checker、A0 系=冻结台账为准（计数口径见 EXPERIMENT_INDEX counts_definition）
结论证据状态分布：claim 48 条中 RAW_CHECKED 22 / REPORT_ONLY 24 / 混合 2；关键缺口=legacy 已删 outputs 约 40 单元（归档在位、关键项已抽核）
新增定位到的漏项：EXPERIMENT_AUDIT“封存表 448 行”实为 280 行（C0048）；P4 stage3 median 聚合细节差异（复算 1.2773/0.020282 vs 报告 1.29363/0.020728，均值/CI/p 精确一致）；README“P4 未启动”过期陈述（既有已知，确认）
发现/修正/仍未解决的历史冲突：已解决=A0E/A0E2、mv RETRACTED、A′/Branch A、F0 ordering+reference、F3.5 O_prop、G1c BLOCKED/recheck、C0/C0X；仍未解决=shadow t0 不可分辨、F3.5 度量依赖、MIDDLE 谱分类 UNRESOLVED、GTTR 目标轴（LM NLL）对部署声明不对齐
数值复核范围与差异：P4 全量聚合复算一致；F2b b* 恒等式一致；F0 σ_max 阶梯 CSV 复读一致；差异仅上述 2 项登记项
跨表和原件引用检查结果：ID 引用全部存在；report_anchor 全部可定位；抽样 12 条 claim 的原件定位回查通过
包体、哈希和解析检查结果：6 CSV/JSONL 解析通过；ZIP 成员安全、必需物齐全；BUNDLE_MANIFEST 哈希逐文件实算
源目录写入与新实验执行情况：零写入、零训练/GPU/HVP/测试/notebook、未解封任何封存件（P4 SEAL 制品为已获准读取的既有结果）
源文件变化与快照限制：窗口内未观测变化；F4A 可恢复态——不宣称绝对不变
覆盖结论：完整覆盖已声明范围（42/42 单元；发现文件 100% 分类；重要材料未发现遗漏归属）
证据结论：主要主张原件已核对（RAW_CHECKED 22 条含三线终局；legacy 已删单元以冻结状态文档+归档抽核为据——仍有 REPORT_ONLY 层证据缺口，已在各卡标明）
```

自检发现并处理的问题：(1) 初版五张 CSV 存在未转义 ASCII 逗号导致的列错位——已全部以程序化生成（csv.writer）重建并通过列数/引用/锚点三项校验；(2) evidence 目录首建时一处 shell cwd 笔误使 7+14 份副本短暂落在 lab 根的新建 evidence/ 目录——已全部移入审计目录并将该误建目录从 lab 根删除（误建目录内全部为本轮新建文件，未触碰任何既有文件；find 终版清单 23 份）；(3) EXPERIMENT_AUDIT 行数笔误与 P4 median 聚合细节差异登记于台账。
