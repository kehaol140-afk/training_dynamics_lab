# AdamW 训练动力学研究：模型、实验、结果与结论盘点

> 审计目录：`audits/ADAMW_RESEARCH_REVIEW_20260930_061142UTC/`；任务包：`audits/ADAMW_REVIEW_TASKPACK_v2/`（v2）。
> 本报告为只读研究盘点：**未运行任何新实验、未改动三个源目录、未解封任何封存件**；所有结论来自对既有文档、配置、冻结制品与已获准读取的结果文件的静态阅读与轻量 CPU 复算。本报告不构成训练复现。

---

## 0. 摘要与阅读边界

**盘点对象**：`legacy_fluctuation_response`（FR/GTTR 线，2026-09-01→09-26，91 个实验条目）、`optimizer_sensitivity`（F0→F3.5 完结+F4A 进行中）、`continuation_adaptation`（P0→P4 终局 STOP）。三条线共享同一 MiniMind 类训练基质与 legacy 冻结基础设施（vendor+SHA256 模式），构成"legacy 冻结 → 多个新方向分叉"结构。

**三条线各做了什么（研究语言）**：

1. **legacy**：从"自然梯度涨落能否预测人工脉冲响应"（FR 比例律，H8 预注册检验 FAIL）出发，转而建立了**完整的 AdamW augmented-state 切线模型阶梯（A/B/BH_fixed/C）**——含 bias correction、decoupled weight decay 与全局 clip 的精确 Jacobian（clip-JVP）。C 模型在 5M/26M/100M/换语料上把有限时域响应预测做到 R²≈0.999（H≤8 mre 0.0026–0.0219），G3 用真 no-clip 重训确认了 clip-JVP 段的因果地位。随后沿"响应作为决策/控制信号"走了 A0G→A0U 十八轮：**响应计算昂贵（speedup<1）、选择器不优于固定动作、LR 是唯一稳定控制通道、一阶核是短时程对象（无稳定时间衰减律）、可利用信息塌缩到约 1 bit**。GTTR 终局试图把局部几何/二次目标固化成训练规则：Phase B 局部算子 FD 门在 S3 状态不可校准、D1 读出规则不敌固定 LR 网格、R2B 终态不显著、F2a/F2b 证明"导数算得对但用不上"（一阶方向在 δ=0.05 失效；二阶曲率全负使驻点为拟合极大、实际最优方向与二阶预测不一致）。09-26 迁移重组时 GTTR 线终结、目录冻结。
2. **optimizer_sensitivity**：以 G1c 外部 1B 上"primal 稳定 + tangent 爆炸"为 seed evidence，F0 在冻结 74 态上确认一步切线条件数随规模恶化（σ_max 39→290→2198）且随训练自愈；F1 定位因果机制为 **second-moment floor（V_FLOOR_CAUSAL：v 通道单步放大 2.4e9；τ=eps 抬升只改 0.05% forward 即砍 σ_max 70%，27/27 单调）**；F2 证明该病态使 EARLY 相位 hypergradient 实际不可用（MIDDLE 可用）；F2.5 否定了"backward-only v-floor 干预→trust region 再扩张"的因果链（放大由网络曲率通道主导）；F3 给出终判 **SPECTRAL_INSTABILITY**（ρ>1.05 遍布 EARLY 窗、被 LR-source 方向选择性激发、receiver 模块分布式、无逐步 constructive alignment）；F3.5 判 **METRIC_DEPENDENT**（unstable 子空间耦合/持续性在 RAW 与 DIML 度量下反向）；F4A 制图进行中（17/74 units）。
3. **continuation_adaptation**：回答"预算改变+β2 迁移下继承 AdamW state 是否仍适配、简单清零式适配能否打败认真调参的续训"。P4 全矩阵（56 C0×8 运行=448 runs，两段式封存评测）当日完成，裁决 **STOP**：C1（保 m 清 v）大幅劣化 +1.587 nats、C2（清 m 保 v）劣化 +0.0194，0/8 seeds 改善；描述性发现 B−D=−0.0747（新 HP 下继承优于重置）、B−A=−0.0139（改 β2 0.999→0.99 略优，描述性）。方向按预注册停止条件证伪终止。

**当前可保留的核心结论**（详见 §7 跨项目表与 §8 勘误台账）：C 阶梯切线模型的有限时域预测力（多尺度复制+因果分解）、V_FLOOR_CAUSAL 机制、SPECTRAL_INSTABILITY、LR 唯一稳定通道、一阶响应短时程性、终点收益与短期信号脱钩（三条线独立反复出现）、以及 continuation 的阴性终局。

**重要缺口（直接可见）**：(a) legacy 约 40 个实验的原始 outputs 已于 2026-09-29 按清理规程删除（GitHub 归档+bundle 备份留档，本服务器仅 archive_staging 暂存区可回查部分制品）——这些单元的证据状态多为 REPORT_ONLY，本轮对 A0C/F2a/F2b/R1/R2B/D1/PhaseB/F0/F1 等关键项做了归档原件抽核（RAW_CHECKED）；(b) 模型级外推（h256/4L ≤100M、≤256 步、单语料族）是全部三条线的共同边界；(c) F4A 未完成、F3.5 的度量依赖未决。

---

## 1. 范围、目录与覆盖情况

### 1.1 三个目录及必要的直接来源

| 目录 | 角色 | 状态（本轮读取时） |
|---|---|---|
| `legacy_fluctuation_response/` | FR/GTTR 全部历史实验 + 冻结基础设施 | 只读冻结（git HEAD `6ac4942`，EXPERIMENT_AUDIT 记 status clean）；outputs 经 09-29 两批清理后剩 13 个子目录（v07/G1a/G1b bank、g1c×3、g2、c0x、model_target_alignment、r1、phase_b_fd、a0_fr_audit 3 子目录等） |
| `optimizer_sensitivity/` | F0–F3.5 完结 + F4A 进行中 | 活跃 git repo（无 remote）；F3/F3.5/F4A 提交链完整 |
| `continuation_adaptation/` | P0–P4 终局 STOP | 非 repo；448 final_state.pt 已按清理规程删除，SEAL SHA 台账+全部 metrics/loss 曲线/统计 CSV 在位 |

**直接依赖来源（登记）**：`minimind_base/`（原生框架，按引用理解）；lab 根 `PROJECT_CONTEXT.md`、`PATH_MIGRATION_20260926.md`、`EXPERIMENT_AUDIT_2026-09-29.md`、`CLEANUP_LOG_2026-09-29.md`、三个清理 manifest；`audits/FULL_SERVER_AUDIT_20260926/`（91 条冻结实验索引）；**根外** `/home/b205/projects/training_dynamics_lab_archive_staging/`（被删制品的 GitHub 归档暂存，136M，抽核 12+ 制品）；`legacy_fluctuation_response/AGENTS.md`（历史约束，仅作研究资料；与只读审计无冲突）。

### 1.2 研究单元发现方法与明确排除

方法：三根递归清点（`SOURCE_INVENTORY.jsonl`，5368 发现行+10 追加直接依赖行=5378 行）→ 与 `audits/FULL_SERVER_AUDIT_20260926/02_COMPLETE_EXPERIMENT_INDEX.md`（91 条）、`docs/FR_PROJECT_STATUS.md`（§1–§49a 全文）、`FR_EXPERIMENT_INDEX.md`、optimizer_sensitivity git log、continuation outputs 树**三方交叉**→ 归并为 42 个研究单元（COVERAGE U0001–U0042：legacy 22、opsens 10、continuation 6、直接依赖 4）。特别核查了：有源码无报告（未发现）、有结果无索引（未发现）、只有计划未执行（G1c-external BLOCKED→复活的执行链、F1-1B 取消、Phase B v4 建议未执行）、历史索引存在但路径已迁移（PATH_MIGRATION 映射）、修复记录未反映到总结（C0X 勘误、A0O-A2 理论修正、F0 文档勘误均已在各自最新报告反映）、只剩字节码（theta_protocol.pyc）。

**明确排除**（理由登记于 COVERAGE）：`.git`/`__pycache__`/venv 等 17 个子树（PRUNED_SUBTREE，未枚举内部）；模型权重/语料（.pt/.jsonl 大件，METADATA_ONLY；v07 bank 4.6G 等只登记不加载）；`legacy/minimind/`（与 minimind_base 重复的原生框架副本，按引用理解不逐行审）；Muon 三目录与 ROUND2/ROUND3 审计（任务范围外，仅经 EXPERIMENT_AUDIT 登记其存在）。

### 1.3 覆盖统计、未完成项与源文件变化限制

- 文件分类覆盖：5378 个条目 100% 分类（三根 FILE 5351+PRUNED 17，另 10 条根外直接依赖）；其中 CONTENT_REVIEWED 45+CONTENT_PARTIAL 20 份核心文档/制品（全部协议、状态文档、终局报告、关键 summary/ledger），其余为 METADATA_ONLY（不称已读）。
- 研究单元评阅覆盖：42/42 单元均有评阅状态；REVIEWED 36、PARTIAL 4（U0016 框架快照、U0035 continuation 代码逐行、U0042 minimind_base、U0031 F4A 进行中）、EXCLUDED 1（U0018 minimind 副本）、另有 DIRECT_DEPENDENCY 单元。**文件分类覆盖 ≠ 文件已读**。
- 原始证据状态：三线主要结论中，continuation P4（封存表+裁决）、opsens F0–F3.5（summary/verdict 制品）、legacy 在树制品（E3C locked、mv_theory_final、C0X、G1C 诊断、GTTR alignment）为 RAW_CHECKED；legacy 已删 outputs 的约 40 单元以冻结状态文档+归档暂存区为据（关键项已抽核原件）。
- 源文件变化限制：读取窗口 2026-09-30 06:11 UTC 起；三目录 mtime 均早于窗口（最后写入 09-29/09-30 04:56 的 F3.5 与 F4A monitor log）；F4A 处于可恢复执行态（无进程在跑，本轮未干预），**不能宣称窗口内绝对不变**，仅证关键文件身份（SHA256 抽验见 BUNDLE_MANIFEST）。

---

## 2. 研究演变与问题之间的关系

**legacy（09-01→09-26）**：原始问题是"自然涨落→因果响应"（非平衡思路延续，v2 计划明确不预设 FDT）。E 链建立位级重放+CRN 基础设施并检验 H8（FAIL）后，问题转为"响应由什么构成"——A0C/A0E2 用模型阶梯回答（optimizer 机制+曲率反馈+clip-JVP，暂不需要记忆核）。随后问题转为"响应有没有用"：A0G（效用✓/成本✗）→A0H/A0H15/A0H20（伴随降本的实现闭环）→A0I/A0J（成本工程与缓存失败）→A0K–A0N（闭环：干预有益、选择无增益）→A0O–A0U（optimizer 输入通道：LR 响应干净、时间核无稳定律、控制信息≈1 bit）。GTTR（09-21→09-26）试图把"局部几何/目标"固化为规则：C0/C1/C1L 给出 field 级有限支持，但 Phase B（算子不可校准）、D1（不敌固定 LR）、R2B（终态不显著）、F0（全时域梯度混沌）、F2a/F2b（方向不确认）逐级证伪"模型→规则"的桥。09-26 迁移重组，GTTR 终结、目录冻结。**科学问题的演变与文件迁移是两件事**：PATH_MIGRATION 是物理重组；问题演变链完整记录于 FR_PROJECT_STATUS 各节与 RETROSPECTIVE。

**optimizer_sensitivity（09-26→09-30）**：接住 G1c 1B 的 seed evidence（primal 稳定+tangent 爆炸），把问题定义为"训练稳定时切线/灵敏度的病态"。F0（现象确认）→F1（机制定位+因果干预）→F2（下游后果：hypergradient 相位依赖失效）→F2.5（可用邻域与因果边界：backward-only 干预无效）→F3（机制终判：谱不稳定+方向选择激发+分布式 receiver）→F3.5（耦合结构的度量依赖）。注意 F2.5 与 F1 的关系不是否定而是**边界划分**：F1 的因果性在 forward 干预语义下成立，F2.5 证明其效应须经网络曲率通道才进入 h_tangent、backward-only 干预捕捉不到。F4A 正在把结论做成 scale×phase×seed 地图。

**continuation_adaptation（09-26 当日闭环）**：PROJECT_CONTEXT 吸收 GTTR 教训（判据锚定 final NLL、baseline 必须真调参、第一阶段不用导数方法），把问题改为"state 适配"这一无导数方向；P4 预注册→评审→执行→封存→裁决一日内完成，阴性终局。

---

## 3. 共用定义、训练设置与评价口径

| 项 | v07/legacy 主线（5M） | G1a/G1b（26M/100M） | continuation P4 |
|---|---|---|---|
| 模型 | MiniMind dense 4L×256 GQA 8/4，vocab 6400，tied embed，4,983,296 unique params | 512×7L×8h（26,681,728）/768×13L×12h（100,784,000） | 同 v07 5M（C0 只读加载） |
| 数据 | D0=e3c_subset.jsonl 4096 行（sha `1e657af9…b0f4`）+ partition_v07（train/probe/eval=3936/32/128） | 同 D0；G2 另用 D1=pretrain_hq 4096 行池 | 同 D0+同 partition（V_monitor=probe 32/V_final=eval 128） |
| 优化器 | 原生 AdamW β=(0.9,0.999) eps=1e-8 wd=0.01，global clip 1.0，bf16 autocast（GradScaler 禁用），batch 4×accum 2，seq 128（1024 input slots/step） | 同左 | 同左；臂改 β2 0.999→0.99（load 后改，陷阱已单测） |
| LR | 手写 cosine `lr·(0.1+0.45(1+cos(π·gm/256)))` base 5e-4，无 warmup，逐 micro-batch 写入 | 同左（planned_total=128 步） | P4：压缩剩余 cosine（gm_lr(k)=2t0+2k，终点恒 5e-5）×乘子 |
| 预算单位 | optimizer step（=2 micro；=1024 input slots；token 数按 valid targets 另计） | 同左 | B=(128−t0)/2∈{23..41} 步 |
| 评价 | eval-pool 逐 token CE（mean/p95/p99/CVaR99；`eval_observables`）；A0 系 V_score/V_eval 分离 | 同左 | primary=final V_final NLL（mean）；两段式封存 |
| 差值方向 | 增益=损失下降（正=好）在各报告内注明 | 同左 | d=NLL(Cx)−NLL(A_best)，负=改善 |
| 独立重复单位 | seed（stream 为 state 内局部重复） | 同左 | cell（seed×t0）配对；primary 按 seed 聚类（8 簇） |

**不可共享处**：legacy A0 系的 chi/mre 口径（`a0c _metric` 禁止重定义）不适用于 opsens 的 G/A_v/ρ 口径；continuation 的 V_monitor/V_final 分离是 P4 特有纪律；引用本表仍需逐实验注明差异（如 GTTR 后期 schedule 尾部恒 5e-5、PhaseB/D1 的 256 步续训、opsens 的 fp64 SENS 累积）。

---

## 4. legacy_fluctuation_response

### 4.1 问题、阶段与模型演变
见 §2。模型清单（12 个实质版本）：FR 比例律假说 → mv 闭式（RETRACTED）→ 动量核经验拟合 → **AdamW 切线阶梯 A/B/BH_fixed/C（核心）** → 伴随/共享 VJP 评分器 → 闭环 controller 族 → LR 输入响应理论 → LR 时间核（否定）→ 控制图 J=[LR,clip,wd] → regime-switching（否定）→ GTTR 局部几何场 → GTTR 二次目标 → GTTR 终局规则（F0）。

### 4.2 模型卡（按 MODEL_INDEX 逐项；正文给关键数学）

<a id="model-bc-ladder"></a>**M: adamw-tangent B/C 阶梯**（源：FR_PROJECT_STATUS §2–§4；实现冻结于 `research/src/fr/a0c_adamw_response_propagation_v01.py`）。状态=(θ,m,v,t)；对扰动 δg 的切线递推：
`dm1 = β1·dm + (1−β1)·dc`；`dv1 = β2·dv + 2(1−β2)·c·dc`（c=clip 系数）；`dθ ← (1−lr·wd)·dθ − lr·[dm̂/√v̂ − m̂·d√v̂/v̂]`（带帽量=bias-corrected）。初始脉冲经 `J_clip(g)q = c·q − radial·g`（pulse-before-clip 协议决定）。阶梯：A=动量核 `-η·μ_raw·(1−β1^H)`（经验）；B=完整 AdamW 切线（未来 δg=0）；BH_fixed=B+raw HVP（初始脉冲同 B）；C=B+`clip_jvp(H(loss)·δθ)`（完整切线）。类别：**精确更新**（对冻结 AdamW 一步 map 的解析 Jacobian；H1 在 ε/4 复现 FD 至 0.000146–0.019；A0C 归档 summary 与 torch.optim.AdamW 零梯度步位级一致）。假设/域：bf16 训练、HVP 用 math-SDPA 代理（gap 5.06e-3，caveat 恒伴随）、chi_fd 为有限 ε 中央差分（A0D 证残差主要为 ε 伪影）。验证：H1/A0C/A0D/A0E2/A0F/A0F2/G1a/G1b/G2/G3（C mre 0.0026–0.0219、H>1 C 胜 B 18/18×3、G3 因果）。

<a id="model-f1-opsens-will-be-in-s5"></a>其余模型卡要点：**mv 闭式**（RETRACTED——量纲×ρσq 与全局 q/state-specific q 不一致，是"近似理论失败"而非"AdamW 机制失败"，RED_FLAGS#3）；**LR 输入响应**（A0O-A2 修正后：LR 脉冲为纯 θ 通道推，`e_lr=−adaptive(c_k)−λ_wd·θ_k`，`h_eta=Σ⟨p_th, lr·e_lr⟩`——m/v 对 lr 无关；n=96 Pearson 0.9552）；**LR 时间核**（否定：无稳定衰减律）；**GTTR 局部几何**（`g(θ+s)≈g+Hs` 再经真实 clip，E 聚合门 0.24–0.50 有限支持）；**GTTR 二次目标**（R1 辨识 cond 25.7–173；受限解多落边界）；**GTTR 终局规则**（F0：w/ψ/Z/eta 参数化+fp64 全程前向灵敏度；实现闭环但 T=256 梯度不可用）。完整字段见 `MODEL_INDEX.csv`。

### 4.3 实验卡（91 条；关键卡正文，其余见 EXPERIMENT_INDEX+附录 C）

<a id="exp-e3c"></a>**E3C confirmatory v07**（预注册 H8 主检验）：8 seeds×7 步位 bank；K_8=0.3769 CI[0.191,0.671]（下界>0）、detrended r=0.5406（p=1.5e-4）、LOSO 5/8<6 → **H8_CONFIRMATION: FAIL**。副产品=56 态冻结 bank（后续全部研究的原料）。判定：关联存在、普适比例律不成立。

<a id="exp-a0c"></a>**A0C response propagation**：3 态×H{1,2,4,8}×8 stream；all-12 A mre 6.36/B 0.165(R² 0.839)/C 0.0274(R² 0.9977)；H>1 C 9/9 胜 B；A→B +6.553（**不可解读为 optimizer 记忆单独贡献**——同时改变 precond/bc/clip/LR/wd）；B→C +0.183。本轮全量读校归档 summary（RAW_CHECKED）。

<a id="exp-a0e2"></a>**A0E→A0E2**：旧 A0E 的 BH 用裸 q 跳过 J_clip（H1 即不一致）→ **VOIDED**；修正后 H>1：B 0.2053→BH_fixed 0.1366（curvature +0.0686）→C 0.0219（clip-JVP +0.1148），三项恒等 8.9e-16。**措辞规则**：有害的是"裸 HVP 反馈"，不是 Hessian 本身。

<a id="exp-g-chain"></a>**G1a/G1b/G2/G3**：scale-only 5.354×/20.225×/换语料均 STRONG_REPLICATION（18/18；C R² 0.9995–0.99995）；G3 no-clip 真重训 MECHANISM_CONFIRMED（Δ_clip +0.0940 cluster PI[0.0086,0.2938]；no-clip BH≡C 27/27 位级；curvature 增益不消失反更大）。**G1c 外部 1B**：HF 路径 BLOCKED→直链复核推翻→feasibility Phase2 C 分支 h=7 NaN（fp16 溢出近因+scale-dependent 主因，A/D 排除）→中止，降级 seed evidence。

<a id="exp-a0o-u"></a>**A0G→A0U 效用/控制链**：A0G 效用成立（Gain 1.54e-4，H8 C vs B CI 全正）/成本不成立（speedup<1 无 break-even）；A0H/15/20 伴随实现闭环+效用点估计 +1.467e-4（探索性）；A0J 缓存 TIME_SCALE_NEGATIVE（margin 差 2–3 量级）；A0K 闭环 CASE A（+7.44e-4）但**选择器 M5=−1.29e-4 不优于固定**；A0L/A0N B≥C；A0M phase 结构 CASE A（共模 8–10× 衰减、argmin 身份 phase 依赖、秩为噪声）；A0O Q1-Q3 YES；**A0P 时间核 gate FAIL**（无 exp/power 律、CV(τc)=3.32、长噪声尾）；A0Q LR 唯一稳定通道；A0S 可控性坐标 Spearman 0.762 LOSO；A0T 管线 PASS（+4.41e-4，35/36）+A0T-extra 身份=全局缩放+不持久反转；A0U schedule≈固定缩放延迟 6 步（可利用信息≈1 bit）。

<a id="exp-gttr"></a>**GTTR 链**：alignment 审计 MISALIGNED（全部读数=LM NLL 轴，短期 gain 被三处证据证伪为最终收益代理）；Phase A 校准基线；**Phase B v3 S3 门终止**（fd_rel 0.7061>0.20，同代码路径 S0-S2 通过→S3 局部算子不可校准，非实现问题；FD diagnostic 确认位级可复现）；**D1 NO_OBSERVED_GAIN**（QH_RAW@256 6.895 vs 固定 LR200 6.701，seed2030 示例；最优在 2.0× 网格边界）；**R1** 二次辨识完成（离线）；**R2B** h1 FULL−LR −2.877e-4（SE 4.898e-4）即时有利但 **G_struct(256)=+3.362e-4（SE 5.634e-4）不显著**、3/12 反转；**CB1** 恒等式 36/36 但 rho 非预测子；**F0 BLOCKED_AT_CALIBRATION**（T=2–16 SENS=FD 0.1% 一致；T=256 局部导数与宏观 FD 差 4.5e5 倍）→CALFIX（b 坐标 h256 CALIBRATED；a 坐标 FD 自身不一致）→IC（2 缺陷修复）→F1（四层无理论失败；失败仅在 FP32 真实模型 FD 分辨）→**F2a DIRECTION_NOT_CONFIRMED**（b=+0.02 小 δ 同向、δ=0.05 失效）→**F2b 二阶失败**（曲率全尺度负 −47.2/−22.0/−21.3 → 二次模型域内无极小；实际最优 +0.02 与二阶驻点 −0.0146 反向；本轮复算 b*=−g/h2 恒等式精确一致）——"**导数算得对但用不上**"，GTTR 实质终局。

### 4.4 主要结果、支持范围与未决部分
正结果：切线阶梯（多尺度+因果分解+ε 收敛）、LR 通道物理、可控性坐标、闭环"干预有益"。负结果：比例律、mv 理论、regime 切换、时间核、选择器增值、schedule 发现、GTTR 规则化（三线）、缓存。未决：shadow update 通道（t0 不可分辨）、GTTR 目标对齐（LM NLL 轴内的部署声明）、E4 系探索项、G1c 外部轴（未覆盖）。

### 4.5 勘误、冲突与当前有效结论
勘误台账见 §8。当前有效：C 阶梯+其机制分解（修正后）、LR 响应（A2 后）、A0H20 点估计（限定语）、一切"选择器不增值/时间核不存在/短期≠终点"负结果。禁引：旧 A0E、mv_theory_final、（A0E 系 BH 数值）。

---

## 5. optimizer_sensitivity

### 5.1 问题、阶段与模型演变
见 §2。模型：F0 对角切线 J₀ → F1 分块全态 Jacobian+v-floor 干预 → F2 hypergradient 测量对象 → F2.5 trust radius → F3 耦合算子+谱 → F3.5 双度量子空间耦合 → F4A 制图（进行中）。

### 5.2 模型卡（关键数学）

<a id="model-f0"></a>**F0 对角切线**：c=0 锚点（下一步零梯度）处一步 AdamW map 的梯度→θ′ 通道 Jacobian 逐坐标对角 `G_i = lr(1−β1)/((1−β1^(t+1))(√v̂₁_i+eps))`（v̂₁=β2·v/(1−β2^(t+1))）；θ 通道因子 (1−lr·wd)。**有效域**：c_i=0 坐标上精确成立、与未知真实 batch 无关、clip 不激活；NOT_ESTIMATED=clip 径向耦合/c≠0 交叉项/HVP 反馈。

<a id="model-f1"></a>**F1 分块全态 Jacobian**：`dθ′=(1−lr·wd)dθ−M·dm+Dv·dv`，`M=(β1/(1−β1))G`，`Dv=lr·m̂₁·(β2/(2·bc2·√v̂₁))/(√v̂₁+eps)² ∝ m̂·v̂^{-3/2}`（v 通道爆炸的解析根源）。反事实干预 `v_τ=max(v,τ²)`（frozen-state probe）。**勘误**：F0 随记"m 通道增益=β1·G"混淆了动量递推与通道导数；正确为 ×9——F0 全部测量走梯度通道不受影响。

<a id="model-f3"></a>**F3 谱与耦合**：forced 臂（持续切线源，强度 α=曲率反馈缩放）与 SO impulse 臂（q0 单源后自由传播）；局部一步合成算子谱半径 ρ(J_t)（matrix-free Arnoldi m=16，30/30 reliable，residual≤1.3e-3）；σ_max≈1e22–1e26（v 通道方向主导，与 F1 同源）。**时序语义**（ordering bug 修复后冻结）：pre-step grads→clip→每臂 HVP→hom_step→advance→+source。

### 5.3 实验卡
F0（§5.2 域内 74 态：σ_max 39.4/289.8/2197.7 阶梯、A_random 1.05→14.8、FD 1e-11、0 精确零 v、自愈 36×、embedding tied-head 机制修正 G1c 预期）；F1（V_FLOOR_CAUSAL 四线合一）；F1-1B（取消，0 字节）；F2（EARLY 2/3 rel_err>1@H16；MIDDLE 8–14%；Pearson 0.823；FD 长程自身退化）；F2.5（δ* 塌缩三格同型+干预无效+hC/hB 3.6×–1.5e5×）；F3-compat（R0 跨进程逐位 spread=0、R1 全 PASS、frozen reference sha `6f2650e0…`；archive 1e-12 重放在新环境不可达的 drift 现象如实登记）；F3 主实验（RQ1–RQ5 见 §5.2/§5.4；RQ3 四次 INVALID→chunked streaming 重写后逐位锚定 0 mismatch）；F3.5（METRIC_DEPENDENT；O_prop 定义修正重跑记录在案）；F4A（17/74，无结果）。

### 5.4 主要结果、支持范围与未决部分
支持：病态存在性与规模趋势（FD 验证）；v-floor 因果（forward 语义）；hypergradient 相位窗口；谱不稳定+方向选择激发+分布式 receiver；MIDDLE/EARLY 差异=耦合与算子演化非病态存在性。边界：全部锚点 c=0/H=1 递推→H 步外推须计复合；F2.5 证明 backward-only v 通道干预<1% 效应；F3.5 证明耦合结构 metric 依赖（RAW 几何被 v-floor 主导、缺操作性）；"病态→长期训练发散"的断言**不受支持**（primal 全程稳定）。未决：F4A；1B 轴（取消后未复测）；MIDDLE cell 的 SPECTRAL 分类（UNRESOLVED：有谱证据无 transient）。

### 5.5 与 legacy 的共享资产、版本关系及区别
vendor 15 文件（SHA256 双向核对；仅 minimind_adapter 2 行 import 改动）+F1 追加 3 个 G1C 适配器；`adamw_tangent_step`/`clip_jvp` 唯一定义源同 legacy A0C——数学同一、任务不同（legacy 问"切线能否预测响应/指导动作"，opsens 问"切线自身的病态与后果"）。legacy G1c 失败诊断是本项目的 seed evidence；F0 对 G1c 的归因（SCALE_TREND 主+PRECISION_ARTIFACT 近因+精确零=外部配置特有）修正了legacy 的初步预期。legacy 某分支错误（如 A0E BH bug）**不**否定本目录证据（独立实现+FD 验证+逐位锚定链）。

---

## 6. continuation_adaptation

### 6.1 问题、阶段与建模/假说
见 §2。模型=臂语义（state 通道操作）+schedule 变换规则（数学上精确：T_rem/B=2 无插值、端点恒等 2t0+4B=256）。

### 6.2 实际状态干预、对照与预算定义
臂（冻结）：A=继承+原 β+乘子网格 {0.5,1,2}+单次自动扩张 {0.25,4}（选择判据=final V_monitor NLL，probe 32 样本）；B=继承+β2 0.99（乘子同 A 选中值）；C1=保 m 清 v；C2=清 m 保 v（step 均保持 t0——bias-correction 瞬态属被测定义）；D=全清零+step 归零。CRN：同 cell 全臂同 batch manifest。预算 B=(128−t0)/2∈{23..41} 步。封存：runs 阶段不计算 V_final；Stage2 SEAL_LOCK 后一次性评测（本审计读取的 sealed 表为已获准的既有结果）。

### 6.3 实验卡与执行覆盖
P3 smoke（8/8 checks，含 A_repeat 位级确定性）；P4 stage0（位级抽查）；P4 stage1（448 runs=56 cells×8 臂全完成；56 selection ledger：如 s2030_t046 选中 4.0× boundary_unresolved）；stage2（280 行封存表=56×5 臂；SEAL_LOCK n_runs=448）；stage3（裁决 STOP）。**执行覆盖完整**；448 final_state.pt 已按 09-29 清理规程删除（SEAL SHA 台账为完整性锚点）。

### 6.4 逐条件与总体结果、统计口径
primary：C1−A_best 均值 +1.587064（cluster bootstrap CI[1.2352,1.9550]、p=1.0、0/8 seeds、0/7 ckpt、逐 ckpt 均值 0.714→2.741 随 t0 递增）；C2−A_best +0.019356（CI[0.0141,0.0246]、p=1.0、0/8、0/7）。secondary 描述性：B−A_best −0.013881（8/8 seeds 正、naive CI 反保守标注）；D−A_best +0.060853；B−D −0.074735；C1−C2 +1.567708。本轮全量复算与 stage3 一致（均值精确一致；median 复算 1.2773 vs 报告 1.2936/0.020282 vs 0.020728——聚合细节差异，不影响任何判定）。

### 6.5 原停止决定、本轮复核与适用边界
原决定 STOP（预注册 §8：C≤A 触发；README 09-26 13:42"未启动"被同日 14:26 执行超越——EXPERIMENT_AUDIT 已澄清）。本轮复核：封存表与裁决制品在位、复算一致、统计口径（Holm 族/seed 聚类/单侧）与冻结协议一致。**边界**：h256/4L/B≤41 步/单语料/β2 单点迁移；A 网格 56/56 扩张后仍落边界（boundary_unresolved）——按协议评审 §4.4 该情形降级 C>A 结论强度，但本例方向已是 C≤A，STOP 不受影响；强 baseline 覆盖不足对"B 略优于 A"的描述性解读同样适用（A 未在 4.0× 外继续探索）。停止决定保留，本轮不重开。

---

## 7. 跨项目结论表

| 现象或主张 | 模型/实验 ID | 实际证据与 claim ID | 能支持的结论 | 不能推出的结论 | 缺失证据 |
|---|---|---|---|---|---|
| AdamW 切线阶梯（含 clip-JVP/曲率反馈）预测有限时域响应 | legacy/M:adamw-tangent；H1/A0C/A0D/A0E2/A0F2/G1a/G1b/G2/G3 | RAW/REPORT：C mre 0.0026–0.0219、18/18×3、G3 因果（C0006–C0010） | 5M–100M、H≤8、MiniMind 系、该协议内 C 是可用预测器；clip-JVP 段因果 | 任意幅度（有限 ε caveat）、H>8 长时域、外部 1B、非 MiniMind 配置 | H>8 域、1B 复测（取消） |
| second-moment floor 因果导致切线病态 | opsens/M:full-state-blockwise-J；F1 | RAW：A_v 2.4e9、τ=eps −70%/forward 0.05%、27/27 单调（C0036） | c=0 锚点、frozen-state 干预语义下的因果 | 该干预作为训练算法的收益；backward-only 干预能修复 h_tangent（F2.5 否定） | 真训练中 τ 干预的长期影响 |
| hypergradient 可用性窗口随训练自愈 | opsens/M:hypergradient-heta；F2/F2.5 | RAW：EARLY rel_err>1/MIDDLE 8–14%；δ*(H≥2)=0（C0038/C0039） | 100M/该相位结构下 EARLY 不可用 MIDDLE 可用；FD 分辨率地板 | 一切规模/相位的一般结论；"切线错误"（H≥2 观测等价） | 更多 seed/规模/独立 FD 参照 |
| 谱不稳定+方向选择激发（EARLY 放大机制） | opsens/M:local-spectrum-rho + curvature；F3 | RAW：ρ>1.05 30/30、G32 比 86×/744×/1.31×、SO G16 31/108/2.0（C0041） | 冻结判据下的机制分类；receiver 分布式；MIDDLE 差异在耦合 | 特定模块干预能消除增长（RQ3 反例）；unstable 子空间耦合的普适解释（F3.5 METRIC_DEPENDENT） | F4A 制图；MIDDLE transient |
| 响应作为动作选择器有增值 | legacy A0G–A0U | REPORT：M5 −1.29e-4、B≥C×2、信息≈1 bit（C0016/C0017/C0023/C0024） | 本协议/规模下选择器不优于固定动作 | "响应计算无用"（效用/方向信息仍在）；其它候选池设计 | 大 sign-多样性 bank、等墙钟大规模 |
| 一阶响应核存在稳定时间衰减律 | legacy/M:lr-temporal-kernel；A0P | REPORT：gate FAIL、CV 3.32（C0020） | 一阶核是短时程对象 | 长时程外推任何一阶导数（与 F2a 互证） | 二阶/记忆项的替代桥梁（未建立） |
| 局部模型→训练规则的桥 | legacy GTTR（PhaseB/D1/R2B/F0/F2a/F2b） | RAW（归档）：S3 门、NO_OBSERVED_GAIN、+3.36e-4(NS)、4.5e5 倍差、DIRECTION_NOT_CONFIRMED（C0029–C0032） | "模型局部有效≠规则有效"；短期信号与终点脱钩 | 局部几何/二次辨识本身无效（R1/C1 有支持） | 任何把已校准导数变成动作的成功路径（未发现） |
| 变预算下简单 state 适配优于调参续训 | cont/M:state-adaptation-arms；P4 | RAW：STOP、C1 +1.587/C2 +0.0194、p=1.0（C0045） | 该情景（B=T_rem/2、β2 0.999→0.99、h256、≤41 步）下清零式适配无价值；继承优于重置（描述性） | 全部 state 适配方法（仅测了清零式）；其它预算/β 组合；规模外推 | "聪明"重构类（协议明禁）；第二阶段场景 |
| 短期改善预测终点收益 | 三线独立 | A0K/R2B/D1/GTTR-alignment/P4 secondary | 三线一致否定（脱钩/反转） | —— | 正向桥接机制（未找到） |

---

## 8. 重要勘误与冲突台账

| 问题/版本 | 旧说法与来源 | 新证据与来源 | 实际修复/重跑状态 | 哪些结果受影响 | 当前可保留判断 |
|---|---|---|---|---|---|
| 旧 A0E BH 初始化 | "raw curvature 有害 gain_H<0"（A0E v01） | BH 裸 q 跳过 J_clip（A0E2 复现 H1 不一致） | A0E2 修正后重算（同 run 对 A0C gap=0） | 仅 A0E v01 全部数值（禁引） | 曲率正贡献+clip-JVP 再改善 |
| mv_theory_final | "v 路径改善" | 量纲/方向不一致+consistent 0/8 | mv_theory_consistent 严格重检（无重训练） | final 报告（RETRACTED 禁引） | v 路径不改善（负结果有效） |
| A0O dc-channel 公式 | 旧公式污染 m/v | A2 修正：纯 θ 通道推（先于有效结果） | 修正后产出全部有效结果 | 修正前无有效结果 | 现行理论成立 |
| C0 聚合门 | "field NOT_SUPPORTED_IN_PILOT"（C0） | C0X：门被实现成逐点门（ERRATUM_REQUIRED） | 复算聚合 E 通过；C1/C1L 独立库复测（field 支持） | C0 判定措辞（原 verdict 保留不覆盖） | field 有限支持；shadow 仍 UNRESOLVED |
| A0H-1.5 A′ FAIL | "决策规则层失效"归因 | §21 修订 UNRESOLVED→§22 Branch A：驱动 selector 方向写反 | 驱动修复+离线纠正重评分 3/3 最优；A″（A0H20）独立批重验 | A′ 3/3 FAIL 原始记录保留（降级 dev） | 伴随保真成立；A0H20 点估计为正 |
| F0 文档 m 通道公式 | F0 随记 "m 通道增益=β1·G" | F1 勘误 M=(β1/(1−β1))G | 文档级勘误（F0 测量不受影响） | 无测量影响 | F1 闭式为准 |
| F3 ordering bug+环境漂移 | F3 首跑 BLOCKED（G1/G2 超容差） | amendment d63a8e1：真 bug（dc 在 step 后）+真 drift（同日同环境逐位可达） | bug 修复+current-env frozen reference 建立+gate PASS 后全矩阵重跑 | 首跑 blocked 制品保留为 provenance | F3 全部现行结果对 frozen reference 逐位 |
| F3 RQ3 执行缺陷 | 4 次启动 0 数据行 | RAM 136GB thrash+SO h≥2 无传播 | chunked streaming 重写（4fc24fe）+对已提交臂逐位锚定 0 mismatch 后完成 | 4 次旧尝试 INVALID（banner 保留） | 现行 RQ3 数据有效 |
| F3.5 O_prop 定义 | 未归一化实现偏差 | 冻结定义=per-vector 归一 | 首 cell 删除重算（锚点重 PASS） | 该 cell RAW 度量 | 现行 F3.5 结果有效 |
| G1c BLOCKED | "EXTERNAL_CHECKPOINT_UNAVAILABLE" | 直链复核：官方 .pt 四件齐全 | recheck 通过→feasibility 执行→C 分支失败中止 | 初判（核验路径错误，非科学改判） | 外部 1B 轴未覆盖+机制归因成立 |
| continuation README | "P4 GPU 矩阵未启动"（09-26 13:42） | 同日 14:26 stage3 完成 | 实际执行完毕（EXPERIMENT_AUDIT 澄清） | 无科学影响 | 以 outputs 为准 |
| EXPERIMENT_AUDIT 行数 | "封存表 448 行" | 实测 280 行（448=SEAL_LOCK runs） | 本轮登记（C0048） | 审计文档单处表述 | 不影响其结论 |
| P4 stage3 median | 报告 median 1.29363/0.020728 | 本轮复算 1.2773/0.020282 | 聚合细节差异（均值/CI/p 精确一致） | 无判定影响 | 以均值+CI 为引用口径 |

---

## 9. 已有研究基础与尚未回答的问题

### 9.1 可保留的数学与实验成果
C 阶梯切线模型+机制分解（多尺度复制、因果干预、ε 收敛、逐位复现链）；LR 输入响应的干净理论与验证；可控性坐标；V_FLOOR_CAUSAL（四线合一）；SPECTRAL_INSTABILITY+分布式 receiver+方向选择性；"短期≠终点、选择器不增值、信息≈1 bit"的成组负结果；continuation 阴性终局与 B/D 描述性对照；位级重放/CRN/封存/预注册治理范式与 v07/G1a/G1b 冻结 bank。

### 9.2 尚缺证据的模型—预测—优化联系
从"切线/谱/可控性"到"训练收益"的每一环：局部导数→有限步长（F2a 断裂）、局部目标→终点 NLL（R2B 断裂）、响应→调度（A0U 退化）、state 适配→超过调参 baseline（P4 断裂）、v-floor 修复→h_tangent 可用（F2.5 断裂，backward-only 语义）。**共同模式**：模型在自身尺度内正确、在"变成动作"处失效；失败位置可由谱/方向耦合/时间尺度解释，但尚无一条打通的路径。

### 9.3 资产复用清单

| 资产 | 真实路径与版本 | 已验证能力 | 使用前提/限制 | 可直接复用/需校准/不建议依赖 |
|---|---|---|---|---|
| v07 bank（56 态） | `legacy_.../e3_confirmatory/v07/`（sha 锚定） | 多 seed×多 checkpoint 完整训练态；roundtrip 位级 | 只读；单语料/5M | 可直接复用 |
| G1a/G1b bank | `legacy_.../generalization_g1{a,b}_*/bank/` | 26M/100M 9 态 | 只读；覆盖空洞（F4A 已登记） | 可直接复用 |
| full_state/rng/batch_manifest/stream 四件套 | `legacy_.../research/src/fr/`（vendored 至两新项目） | 位级重放+CRN | theta_protocol 仅 pyc | 可直接复用（pyc 部分谨慎） |
| adamw_tangent_step/clip_jvp | 同上（唯一定义源） | FD 1e-11 验证 | math-SDPA caveat 恒伴随 | 可直接复用 |
| eval_observables NLL | 同上 | eval-pool 逐 token CE | 池小→SE 需预注册 | 可直接复用 |
| opsens f0/f1 统计件（G_i/A_v/v-floor） | `optimizer_sensitivity/src/opsens/` | 74 态验证 | c=0 锚点语义 | 可直接复用 |
| opsens frozen reference + checker | `optimizer_sensitivity/outputs/f3_compatibility/` | 环境复航契约 | 环境变更须重走 R0/R1 | 可直接复用（同环境） |
| continuation P4 全套协议+statistics | `continuation_adaptation/{docs,configs,src}` | 448 run 淘汰矩阵当日出终局 | final_state 已删（重算受限） | 可直接复用（流程范式） |
| GTTR F0/F1 灵敏度实现 | legacy commit `6ac4942` 保护入库 | 合成 5.6e-17；b 坐标校准 | T≥32 混沌区 | 需校准（长时域不可用） |
| theta_protocol.pyc | legacy research/src/fr | 行为等价（逐位复现验证） | 源码丢失 | 不建议依赖（新 runner 另写） |
| 旧 A0E v01 / mv_theory_final | 禁引清单 | —— | —— | 不建议依赖 |

---

## 10. 交付自检与剩余限制

详见 `SELF_CHECK.md`（逐项 25 条+摘要）。要点：三根全覆盖（42 单元全评阅）；主要主张中 P4/opsens 系/在树 legacy 制件 RAW_CHECKED，已删 outputs 的约 40 单元 REPORT_ONLY（关键项归档抽核）；本轮零源目录写入、零新实验；数值复核 3 项一致+2 项差异登记（P4 median 细节、EXPERIMENT_AUDIT 行数）；ZIP 含全部交付物与证据副本（BUNDLE_MANIFEST 记录读取窗口/排除/哈希）。

---

## 附录 A：单模型卡
全部 22 个模型版本见 `MODEL_INDEX.csv`（正文锚点：#model-fr-prop/#model-mom-kernel/#model-mv-retracted/#model-bc-ladder/#model-controller/#model-adjoint/#model-lr-response/#model-kernel/#model-controlmap/#model-regime/#model-gttr-geo/#model-r1/#model-f0/#model-f0-opsens 见 §5.2 锚 #model-f0/#model-f1/#model-f2/#model-f25/#model-f3/#model-f3-rho/#model-f35/#model-f4a/#model-cont-arms/#model-cont-sched）。正文 §4.2/§5.2/§6 已给关键数学；未验证模型（F4A）已标"未检验"。

## 附录 B：单实验卡
`EXPERIMENT_INDEX.csv` 共 69 行逻辑实验（legacy 48/opsens 9/continuation 2；含 E 链合并行）。正文 §4.3/§5.3/§6.3 给关键卡；次要实验（E4 系、A0I 子项、prep 链、G1c 前两轮、Phase A、CB1、IC 等）的紧凑卡内容即 EXPERIMENT_INDEX 对应行（问题/协议/结果/判定/证据状态/去向齐全），配合 `KEY_RESULTS.csv` 40 项数值记录与来源定位。

## 附录 C：完整索引与证据说明
包内索引：MODEL_INDEX（23 模型版本）/EXPERIMENT_INDEX（69 逻辑实验行）/KEY_RESULTS（40 数值记录）/CLAIM_LEDGER（48 条主张）/COVERAGE（42 研究单元）/SOURCE_INVENTORY（5378 发现行）。`evidence/` 收录关键小原件副本（保留相对路径层次）：P4 stage3/selection ledger/sealed 表头、opsens F0 power_iteration/F3 summary_final/F3.5 verdict、legacy E3C locked 摘录、A0C 归档 summary 摘录、F2a/F2b 数据、清理 manifest 摘录、复算脚本与输出。全部摘录标注原件路径与定位；归档暂存区制品以绝对路径标注（根外来源）。

### C.1 主张锚点（与 CLAIM_LEDGER.report_anchor 对应）

<a id="claim-fr"></a>**FR 比例律组**（C0001–C0002）：见 §4.3 exp-e3c 卡。
<a id="claim-a0"></a>**A0 审计组**（C0003–C0005）：见 §4.1/§4.2。
<a id="claim-mv"></a>**mv 理论作废**（C0004）：见 §8 台管第 2 行。
<a id="claim-bc"></a>**切线阶梯组**（C0006–C0010）：见 §4.2 model-bc-ladder 与 §4.3 exp-a0c/exp-a0e2/exp-g-chain。
<a id="claim-a0g"></a>**效用/成本**（C0011）；<a id="claim-a0h"></a>**伴随实现**（C0012–C0014）；<a id="claim-a0h20"></a>**A0H20**（C0014）：见 §4.3。
<a id="claim-a0j"></a>**缓存时间尺度**（C0015）；<a id="claim-a0k"></a>**闭环**（C0016）；<a id="claim-a0ln"></a>**混合/相位门控**（C0017）；<a id="claim-a0m"></a>**phase 结构**（C0018）：见 §4.3。
<a id="claim-a0o"></a>**LR 响应**（C0019）；<a id="claim-a0p"></a>**时间核否定**（C0020）；<a id="claim-a0q"></a>**控制图**（C0021）；<a id="claim-a0s"></a>**可控性**（C0022）；<a id="claim-a0t"></a>**控制器身份**（C0023）；<a id="claim-a0u"></a>**schedule 否定**（C0024）：见 §4.3。
<a id="claim-b06"></a>**regime 否定**（C0025）：见 §4.1。
<a id="claim-gttr-geo"></a>**GTTR 几何**（C0026）；<a id="claim-g1c"></a>**G1c 1B**（C0027）；<a id="claim-align"></a>**对齐审计**（C0028）；<a id="claim-gttr-rule"></a>**规则化否定**（C0029）；<a id="claim-r1"></a>**二次辨识**（C0030）；<a id="claim-f0"></a>**F0 实现/可用性分层**（C0031）；<a id="claim-f2"></a>**F2a/F2b**（C0032）；<a id="claim-phasea"></a>（C0033）；<a id="claim-cb1"></a>（C0034）：见 §4.3 exp-gttr。
<a id="claim-opsens-f0"></a>**opsens F0**（C0035）；<a id="claim-opsens-f1"></a>**F1 机制**（C0036）；<a id="claim-opsens-f1b"></a>**1B 取消**（C0037）；<a id="claim-opsens-f2"></a>**F2**（C0038）；<a id="claim-opsens-f25"></a>**F2.5**（C0039）；<a id="claim-opsens-f3c"></a>**compat**（C0040）；<a id="claim-opsens-f3"></a>**F3 谱判**（C0041）；<a id="claim-opsens-f35"></a>**F3.5 度量依赖**（C0042）；<a id="claim-opsens-f4a"></a>**F4A 进行中**（C0043）：见 §5。
<a id="claim-cont-smoke"></a>**continuation smoke**（C0044）；<a id="claim-cont-p4"></a>**P4 STOP**（C0045）；<a id="claim-cont-bd"></a>**B/D 描述性**（C0046）：见 §6。
<a id="claim-theta-pyc"></a>**pyc 事件**（C0047）；<a id="claim-audit-rowcount"></a>**审计行数勘误**（C0048）：见 §8。

### C.2 锚点登记（补全索引 report_anchor 的显式锚点；正文已有锚点不重复）

以下锚点对应各索引行的正文位置（内容见对应表格/卡片行）：

- <a id="claim-a0e"></a>claim `C0008` → 见本报告对应章节与索引行。
- <a id="claim-aprime"></a>claim `C0013` → 见本报告对应章节与索引行。
- <a id="claim-gen"></a>claim `C0010` → 见本报告对应章节与索引行。
- <a id="exp-a0audit"></a>exp `legacy/E:A0-audit-chain:v01-v08` → 见本报告对应章节与索引行。
- <a id="exp-a0d"></a>exp `legacy/E:A0D-epsilon:v02` → 见本报告对应章节与索引行。
- <a id="exp-a0e"></a>exp `legacy/E:A0E-voided:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0f"></a>exp `legacy/E:A0F-A0F2-cross:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0g"></a>exp `legacy/E:A0G-decision-utility:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0h"></a>exp `legacy/E:A0H-adjoint:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0h15"></a>exp `legacy/E:A0H15-vjp-shared:v01-r2` → 见本报告对应章节与索引行。
- <a id="exp-a0h20"></a>exp `legacy/E:A0H20-corrected-accept:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0i"></a>exp `legacy/E:A0I-A:a0i-a` → 见本报告对应章节与索引行。
- <a id="exp-a0ib"></a>exp `legacy/E:A0I-B:a0i-b` → 见本报告对应章节与索引行。
- <a id="exp-a0j"></a>exp `legacy/E:A0J-cache:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0k"></a>exp `legacy/E:A0K-closed-loop:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0l"></a>exp `legacy/E:A0L-mixture:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0m"></a>exp `legacy/E:A0M-temporal:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0n"></a>exp `legacy/E:A0N-phase-scheduler:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0o"></a>exp `legacy/E:A0O-lr-response:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0p"></a>exp `legacy/E:A0P-kernel:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0q"></a>exp `legacy/E:A0Q-map:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0s"></a>exp `legacy/E:A0S-controllability:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0t"></a>exp `legacy/E:A0T-lr-control:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0tx"></a>exp `legacy/E:A0T-extra:v01` → 见本报告对应章节与索引行。
- <a id="exp-a0u"></a>exp `legacy/E:A0U-schedule:v01` → 见本报告对应章节与索引行。
- <a id="exp-align"></a>exp `legacy/E:GTTR-alignment:v01` → 见本报告对应章节与索引行。
- <a id="exp-b0"></a>exp `legacy/E:B0-mechanisms:v01` → 见本报告对应章节与索引行。
- <a id="exp-c0"></a>exp `legacy/E:C0-gttr:v01` → 见本报告对应章节与索引行。
- <a id="exp-c0x"></a>exp `legacy/E:C0X-erratum:v01` → 见本报告对应章节与索引行。
- <a id="exp-c1"></a>exp `legacy/E:C1-probe:v01` → 见本报告对应章节与索引行。
- <a id="exp-c1l"></a>exp `legacy/E:C1L-late:v01` → 见本报告对应章节与索引行。
- <a id="exp-calfix"></a>exp `legacy/E:F0-CALFIX:v01` → 见本报告对应章节与索引行。
- <a id="exp-cb1"></a>exp `legacy/E:CB1-cost:v01` → 见本报告对应章节与索引行。
- <a id="exp-cont-p4"></a>exp `cont/E:P4-full:v01` → 见本报告对应章节与索引行。
- <a id="exp-cont-smoke"></a>exp `cont/E:P0-P3-smoke:v01` → 见本报告对应章节与索引行。
- <a id="exp-d1"></a>exp `legacy/E:D1-direct-readout:v01` → 见本报告对应章节与索引行。
- <a id="exp-e0"></a>exp `legacy/E:E-chain:v01` → 见本报告对应章节与索引行。
- <a id="exp-e1e2"></a>exp `legacy/E:E1-E2-fluctuation:v03-v04` → 见本报告对应章节与索引行。
- <a id="exp-e3"></a>exp `legacy/E:E3-theta-mapping:v05` → 见本报告对应章节与索引行。
- <a id="exp-e3r"></a>exp `legacy/E:E3R-cross-seed:v06` → 见本报告对应章节与索引行。
- <a id="exp-e4"></a>exp `legacy/E:E4A-E4B:v08` → 见本报告对应章节与索引行。
- <a id="exp-f0"></a>exp `legacy/E:F0-solver:v01` → 见本报告对应章节与索引行。
- <a id="exp-f1"></a>exp `legacy/E:F1-closure:v01` → 见本报告对应章节与索引行。
- <a id="exp-f2a"></a>exp `legacy/E:F2a-direction:v01` → 见本报告对应章节与索引行。
- <a id="exp-f2b"></a>exp `legacy/E:F2b-second-order:v01` → 见本报告对应章节与索引行。
- <a id="exp-g1a"></a>exp `legacy/E:G1a-26M:v01` → 见本报告对应章节与索引行。
- <a id="exp-g1b"></a>exp `legacy/E:G1b-100M:v01` → 见本报告对应章节与索引行。
- <a id="exp-g1c1"></a>exp `legacy/E:G1c-external-1b:v01` → 见本报告对应章节与索引行。
- <a id="exp-g1c2"></a>exp `legacy/E:G1c-recheck:v01` → 见本报告对应章节与索引行。
- <a id="exp-g1c3"></a>exp `legacy/E:G1c-feasibility:v01` → 见本报告对应章节与索引行。
- <a id="exp-g2"></a>exp `legacy/E:G2-data:v01` → 见本报告对应章节与索引行。
- <a id="exp-g3"></a>exp `legacy/E:G3-clipping:v01` → 见本报告对应章节与索引行。
- <a id="exp-h1"></a>exp `legacy/E:H1-jacobian:v01` → 见本报告对应章节与索引行。
- <a id="exp-ic"></a>exp `legacy/E:F0-IC:v01` → 见本报告对应章节与索引行。
- <a id="exp-mv"></a>exp `legacy/E:mv-theory:final+consistent` → 见本报告对应章节与索引行。
- <a id="exp-opsens-f0"></a>exp `opsens/E:F0-bank-audit:v01` → 见本报告对应章节与索引行。
- <a id="exp-opsens-f1"></a>exp `opsens/E:F1-mechanism:v01` → 见本报告对应章节与索引行。
- <a id="exp-opsens-f1b"></a>exp `opsens/E:F1-1B:cancelled` → 见本报告对应章节与索引行。
- <a id="exp-opsens-f2"></a>exp `opsens/E:F2-hypergradient:v01` → 见本报告对应章节与索引行。
- <a id="exp-opsens-f25"></a>exp `opsens/E:F2.5-trust-region:v01` → 见本报告对应章节与索引行。
- <a id="exp-opsens-f3"></a>exp `opsens/E:F3-curvature:v01` → 见本报告对应章节与索引行。
- <a id="exp-opsens-f35"></a>exp `opsens/E:F3.5-mode-coupling:v01` → 见本报告对应章节与索引行。
- <a id="exp-opsens-f3c"></a>exp `opsens/E:F3-compat:v01` → 见本报告对应章节与索引行。
- <a id="exp-opsens-f4a"></a>exp `opsens/E:F4A-phase-map:v01-running` → 见本报告对应章节与索引行。
- <a id="exp-phasea"></a>exp `legacy/E:PhaseA-calibration:v01` → 见本报告对应章节与索引行。
- <a id="exp-phaseb"></a>exp `legacy/E:PhaseB-v3:v03` → 见本报告对应章节与索引行。
- <a id="exp-r1"></a>exp `legacy/E:R1-objective:v01` → 见本报告对应章节与索引行。
- <a id="exp-r2b"></a>exp `legacy/E:R2B-bridge:v01` → 见本报告对应章节与索引行。
- <a id="model-adjoint"></a>model `legacy/M:adjoint-shared-vjp:A0H` → 见本报告对应章节与索引行。
- <a id="model-cont-arms"></a>model `cont/M:state-adaptation-arms:smoke-p4` → 见本报告对应章节与索引行。
- <a id="model-cont-sched"></a>model `cont/M:compressed-cosine-remap:P4` → 见本报告对应章节与索引行。
- <a id="model-controller"></a>model `legacy/M:closed-loop-controller:A0K` → 见本报告对应章节与索引行。
- <a id="model-controlmap"></a>model `legacy/M:control-map:A0Q` → 见本报告对应章节与索引行。
- <a id="model-f0-opsens"></a>model `opsens/M:diag-tangent-J0:c0-anchor` → 见本报告对应章节与索引行。
- <a id="model-f2"></a>model `opsens/M:hypergradient-heta:F2` → 见本报告对应章节与索引行。
- <a id="model-f25"></a>model `opsens/M:trust-radius-delta-star:F2.5` → 见本报告对应章节与索引行。
- <a id="model-f3-rho"></a>model `opsens/M:local-spectrum-rho:F3` → 见本报告对应章节与索引行。
- <a id="model-f35"></a>model `opsens/M:unstable-mode-coupling:F3.5` → 见本报告对应章节与索引行。
- <a id="model-f4a"></a>model `opsens/M:phase-map-metrics:F4A` → 见本报告对应章节与索引行。
- <a id="model-fr-prop"></a>model `legacy/M:FR-proportionality:plan-v2` → 见本报告对应章节与索引行。
- <a id="model-gttr-geo"></a>model `legacy/M:gttr-local-geometry:C0-C1L` → 见本报告对应章节与索引行。
- <a id="model-kernel"></a>model `legacy/M:lr-temporal-kernel:A0P` → 见本报告对应章节与索引行。
- <a id="model-lr-response"></a>model `legacy/M:lr-input-response:A0O` → 见本报告对应章节与索引行。
- <a id="model-mom-kernel"></a>model `legacy/M:A-momentum-kernel:v06` → 见本报告对应章节与索引行。
- <a id="model-mv-retracted"></a>model `legacy/M:mv-closed-form:final-RETRACTED` → 见本报告对应章节与索引行。
- <a id="model-r1"></a>model `legacy/M:gttr-quadratic-objective:R1` → 见本报告对应章节与索引行。
- <a id="model-regime"></a>model `legacy/M:regime-switching:B06` → 见本报告对应章节与索引行。
